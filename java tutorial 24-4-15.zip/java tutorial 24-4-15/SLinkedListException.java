public class SLinkedListException extends Exception {
    public SLinkedListException(String message) {
        super(message);
    }
 public SLinkedListException() {
        super("Error operating on CircularLinkedList.");
    }

}
