/**
 * $Id: SimpleList.java,v 1.3.1.1 2006/05/09 09:12:01 saile Exp saile $ 
 */

import java.util.*;

/**
 * This interface defines a subset of SUN's <b>List</b> interface
 */

public interface SimpleList<T>  
{
 /**
  * Appends the specified element to the end of this list
  * @param element element to add to the list
  * @return true
  * @throws NullPointerException when element is null
  */
 public boolean add(T element);
 /**
  * Inserts the specified element at the specified position in this list 
  * @param index Insert position
  * @param element element to add to the list
  * @throws NullPointerException when element is null
  * @throws IndexOutOfBoundsException when index is out of bounds (i < 0 || i>=size)
  */
 //public void add(int index, T element);
 
 /**
  * Returns the element at the specified position in this list.
  * @param index retrieve position
  * @throws IndexOutOfBoundsException when index is out of bounds (i < 0 || i>=size)  
  */
 public T get(int index);
 
 /**
  * Returns the index in this list of the first occurrence of the specified element, 
  * or -1 if this list does not contain this element. 
  * @param o Object to search in list
  * @return position of o or -1 if not found
  */  
 public int indexOf(Object o);
    
 /**
  * Returns true if this list contains no elements.       
  * @return true if list contains no elements, false otherwise
  */       
 public boolean isEmpty();
 
 
 /**
  * Returns an iterator over the elements in this list in proper sequence. 
  * @return iterator over the elements in this list
  */
 // public Iterator<T> iterator(); 
    
 /**
  * Removes the element at the specified position from this list.
  * @return  element.
  * @throws IndexOutOfBoundsException when index is out of bounds (i < 0 || i>=size)  
  */
  public T remove(int index);       
 
 /**
  * Returns the number of elements in this list.
  * @return number of elements in this list
  */
 public int size(); 
           
 /**
  * Returns a view of the portion of this list between the specified 
  * fromIndex, inclusive, and toIndex, exclusive.
  * @param fromIndex  low endpoint (inclusive) of the subList.
  * @param toIndex high endpoint (exclusive) of the subList.
  * @return a view of the specified range within this list.
  * @throws IndexOutOfBoundsException when index is out of bounds   (fromIndex < 0 || toIndex > size || fromIndex > toIndex)  
  */
 //public SimpleList<T> subList(int fromIndex, int toIndex); 
       
 /**
  * Returns an array containing all of the elements in this list in proper sequence. 
  * @return array containing all of the elements in this list 
  */
 //public Object[] toArray(); 
 
 /** 
  * Return a String representing the SimpleList<T>. The result String consists of a '[' then the elements
  * of the list separated by a comma and then a ']' character. A list with the elements "Hello" and "World"
  * should create a String "[Hello,World]".
  * @return String representing the list.
  */  
  public String toString();
           
}
