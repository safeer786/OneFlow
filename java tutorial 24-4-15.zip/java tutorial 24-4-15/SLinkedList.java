import java.util.*;

public class SLinkedList<T> implements SimpleList<T>
{
  // Variables
 private ListNode head;
// private int size;
  // Constructor
 /**
 * Creates a SLinkedList
 */
 public SLinkedList()
 {
 head=null;
 }
 
 // Methods
 /**
 * Appends the specified element to the end of this list
 * @param element element to add to the list
 * @return true
 * @throws NullPointerException when element is null
 */ 
 public boolean add(T element) throws NullPointerException
 {
   if(element ==null)
  {
    throw new NullPointerException("Element is null");
   }
   if(head==null)                                 //for first element
 {
   ListNode temp=new ListNode(element,null);
   //temp.data=element;
   //temp.next=null;
   head=temp;
 }
   else                                            //adding in last     
 {
   ListNode temp=new ListNode(element,null);
   //temp.data=element;
   //temp.next=null;
   
   ListNode curr;
   for(curr=head;curr.next != null;curr=curr.next)
   {
     ;
   }
   curr.next=temp;
 }
 return true;
 }
 
 
 /**
 * Returns the element at the specified position in this list.
 * @param index retrieve position
 * @throws IndexOutOfBoundsException when index is out of bounds (index < 0 || index >= size()) 
 */
 public T get(int index) throws IndexOutOfBoundsException
 {
  if((index>=size()) || (index < 0))
  {
  throw new IndexOutOfBoundsException("IndexOutOfBoundstException");
  //  throw new IndexOutOfBoundstException("List empty");
  }
 else
 {
    ListNode curr;
    curr=head;
    for(int i=0;i<index;i++)
    {
      curr=curr.next;
    }
    return curr.data;
 }
 }
 
 /**
 * Returns the index in this list of the first occurrence of the specified element, 
 * or -1 if this list does not contain this element. 
 * @param o Object to search in list
 * @return position of o or -1 if not found
 * @throws NullPointerException when o is null  
 */  
 
 public int indexOf(Object o) throws NullPointerException
 {
   if(o ==null)
  {
    throw new NullPointerException("Element is null");
   }
   ListNode curr;
   curr=head;
   
   for(int i=0;i<size();i++)
   {
     if(curr.data.equals(o))
     {
       return i;
     }
     curr=curr.next;
   }
   return -1;
 }
 
 /**
 * Returns true if this list contains no elements.       
 * @return true if list contains no elements, false otherwise
 */       
 
 public boolean isEmpty()
 {
 if(size()==0)
 {
   return true;
 }
 return false;
 }
 
 
 /**
 * Removes the element at the specified position from this list.
 * @return  element.
 * @throws IndexOutOfBoundsException when index is out of bounds (index < 0 || index >= size())  
 */
 
 public T remove(int index) throws IndexOutOfBoundsException 
 {
  if(index < 0 || index >= size())
  {
   throw new IndexOutOfBoundsException("invalid index");
 }
   ListNode curr;
   ListNode prev;
   T rev;
   prev=null;
   curr=head;
   for(int i=0;i<index;i++)
   {
     prev=curr;
     curr=curr.next;
   }
   if(index==0 && head.next!=null)                   //list with one element and removing it
   {
     rev=head.data;
     head=head.next;
     return rev; 
   }
   else if(index==0 && head.next==null)            //removing first element from list
   {
     rev=head.data;
     head=null;
     return rev;
   }
   else
   {
     if(curr.next== null)                          // removing last element
     {
       rev=curr.data;
       prev.next=null;
       return rev;
     }
     else                                           // removing from mid  
     {
       rev=curr.data;
       prev.next=curr.next;
       return rev;
     }
   }
 
 }
 
 /**
 * Returns the number of elements in this list.
 * @return number of elements in this list
 */
 
 public int size()
 {
   ListNode curr;
   int i=0;
   for(curr=head;curr.next !=null;curr=curr.next)
   {
     i++;
   }
   i++;
   return i;
 }
 
 
 /** 
 * Return a String representing the SLinkedList<T> The result String consists of a '[' 
 * then the elements of the list separated by a comma and then a ']' character. A list
 * with the elements "Hello" and "World" should return a String "[Hello,World]"
 * @return String representing the list
 */
 
 public String toString()
 {
 String rval = "";
        ListNode curr = head;
        
        for (int i=0; i<size(); i++) {
            rval += curr.data + " ";
            curr = curr.next;
        }
        
        return rval;
 }
 
 /////////////////////////////////////////////////////////
  
 /**
 * This class implements a node in a linked list data structure
 */
 
 private class ListNode {
  private T data;
  private ListNode next;
 
  public ListNode()  {
   data = null;
   next = null;
  }
 
  public ListNode(T element, ListNode link)  {
   data = element;
   next = link;
  }
 }
}