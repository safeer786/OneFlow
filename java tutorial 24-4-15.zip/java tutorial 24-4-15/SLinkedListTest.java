import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class SLinkedListTest extends TestCase {

    private SLinkedList<String> cList;
    
    protected void setUp() {
        cList = new SLinkedList<String>();
    }
    
    protected void tearDown() {
        cList = null;
    }
    
    /**
     * Test add - 1 element
     */
    public void testAdd1() {
        cList.add("a");
        
        try {
            assertEquals("current element", "a", cList.get(0));
       }
      catch (NullPointerException e) {
            fail();
        }
    }
    
    /**
     * Test add - 2 elements
     */
    public void testAdd2() {
        cList.add("a");
        cList.add("b");
        
        try {
            assertEquals("current element", "b", cList.get(1));
       }
      catch (NullPointerException e) {
         fail();
        }
    }  
    
    /**
     * Test add - 3 elements
     */
    public void testAdd3() {
        cList.add("a");
        cList.add("b");
        cList.add("c");
       
        try {
            assertEquals("size", 3, cList.size());
            assertEquals("current element", "c", cList.get(2));
       }
        catch (NullPointerException e) {
          fail();
       }
    }    
        
     //**
     
    /**
     * Test toString - 3 elements
     */
    public void testToString() {
        cList.add("a");
        cList.add("b");
        cList.add("c");
       
        assertEquals("toString", "a b c ", cList.toString());
    }    
    
    public void testindex1() {
        cList.add("a");
        cList.add("b");
        cList.add("c");
        assertEquals("index", 1, cList.indexOf("b"));
        
          
         
    }
            public void testindex2() {
        cList.add("a");
        cList.add("b");
        cList.add("c");
        
        assertEquals("index", 0, cList.indexOf("a"));
        
    }
            public void testindex3() {
        cList.add("a");
        cList.add("b");
        cList.add("c");
          assertEquals("index", 2, cList.indexOf("c"));
        
            }    
    
    public void testRemove1() {
        cList.add("a");
        cList.add("b");
        cList.add("c");
       
       try {
           //  should remove "c" and have "a" as current0
        assertEquals("remove a", "a", cList.remove(0));
            assertEquals("remove c", "c", cList.remove(1));
            assertEquals("remove c", 1, cList.size());
      //      assertEquals("remove c", "a", cList.getCurrent());
        }
        catch (IndexOutOfBoundsException e) {
            fail();
        }
    }    
    
    /**
     * Test remove
     */
     
    
     /**
     * Test remove - exception
     */
   
}
