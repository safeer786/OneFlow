import java.util.Stack;

/**
 *
 * @author G510
 */
public class XMLChecker {
// @SuppressWarnings("empty-statement")
 public boolean wellformedXML(String xml)
 {
  String[] words = xml.split("\\s+");
  if(! words[0].contains("<") || (words[0].contains("<\\")))
  {
     return false; 
  }
  String ch;
  String s1;
  String s2;
  String s3;
  int j=0;
  Stack<String> s=new Stack<String>();
  for(int i=0;i<words.length;i++)
  {
      if(words[i].contains("<") && words[i].substring(1).contains("<"))
      {
          
          for(j=0;j<words[i].length();)
          {
          s1=words[i].substring(words[i].indexOf("<"), words[i].indexOf(">")+1);
          j=words[i].indexOf(">")+1;
         
          if (!(s1.contains("/") ))
          {
              s.push(s1);
               words[i]=words[i].replaceFirst("<", "-");
          words[i]=words[i].replaceFirst(">", "-");
          }
          else
          {
              if(!s.isEmpty())
              {ch=s.pop();
               ch=ch.substring(0, 1) + "/" + ch.substring(1);
              //s1= s1.substring(0, 1) + "/" + s1.substring(1);
                words[i]=words[i].replaceFirst("<", "-");
          words[i]=words[i].replaceFirst(">", "-");
              if(ch.equals(s1))
              {
                  ;
              }
              else
              {
                  return false;
              }
              
              }
              else
                  return false;
              
          }
      }
      }
      

      else if((words[i].contains("/")) && (words[i].contains("<")) )
    {
        if(!s.isEmpty())
        {ch=s.pop();
         ch= ch.substring(0, 1) + "/" + ch.substring(1);
         s3=words[i].substring(words[i].indexOf("<"),words[i].indexOf(">")+1);
         if(ch.equals(s3))
         {
             ;
         }
         else
         {
             return false;
         }
        }
        else
            return false;
    }
    else if(words[i].contains("<"))
    {
        s2=words[i].substring(words[i].indexOf("<"),words[i].indexOf(">")+1);
        s.push(s2);
    }
    else
    {
        ;
    }
  }
 if(s.isEmpty())
 {
     return true;
 }
  return false;
 }
 



    
}