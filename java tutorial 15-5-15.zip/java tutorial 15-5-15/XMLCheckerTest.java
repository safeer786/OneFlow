import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class XMLCheckerTest extends TestCase {

    //Test expect true
      public void test1() {
        XMLChecker x=new XMLChecker();
        String s;
        boolean t=false;
        s="<b>Das ist ein Test <name>Test</name> </b> ";
        assertTrue(x.wellformedXML(s));
      }
      //Test expect false
      public void test2() {
        XMLChecker x=new XMLChecker();
        String s;
        boolean t=false;
        s="<b>Das ist ein Test <name> Test </name> ";
        assertFalse(x.wellformedXML(s));
      }
      //Test expect true
      public void test3() {
        XMLChecker x=new XMLChecker();
        String s;
        boolean t=false;
        s="<b>Das ist ein Test \n<name>Test</name>\n </b>"; 
        assertTrue(x.wellformedXML(s));
      }
     //Test expect false
      public void test4() {
        XMLChecker x=new XMLChecker();
        String s;
        boolean t=false;
        s="Das ist ein Test <name> Test </name> ";
        assertFalse(x.wellformedXML(s));
      }
       //Test expect false
      public void test5() {
        XMLChecker x=new XMLChecker();
        String s;
        boolean t=false;
        s="</b>Das ist ein Test <name> Test </name><b> ";
        assertFalse(x.wellformedXML(s));
      }
       //Test expect false
      public void test6() {
        XMLChecker x=new XMLChecker();
        String s;
        boolean t=false;
        s="</b>Das ist ein Test <name> Test </name></b> ";
        assertFalse(x.wellformedXML(s));
      }
      

}