/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author G510
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import javax.xml.stream.*;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Stack.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import javax.xml.stream.*; //provides XMLEventReader/-factory
import javax.xml.stream.events.*; //all types of XMLEvents
import javax.xml.transform.stream.StreamSource;


public class Addressbook {

    private String adressFileName;
    private ArrayList<Address> addresses = new ArrayList<Address>();

    public Addressbook(String fileName) throws XMLStreamException, FileNotFoundException {
        this.adressFileName = fileName;
        load();
    }
   

    /**
     * Return an ArrayList with the Adresses of this instance
     *
     * @return the addresses
     */
    public ArrayList<Address> getAddresses() {
        return addresses;
    }

    /**
     * Return the name of the file of this Addressbook
     *
     * @return the adressFileName
     */
    public String getAdressFileName() {
        return adressFileName;
    }

    /**
     * Set the name of the file of this Adressbook
     *
     * @param adressFileName the adressFileName to set
     */
    public void setAdressFileName(String adressFileName) {
        this.adressFileName = adressFileName;
    }

    /**
     * Save the content to addressFile
     *
     * @param addressFile
     */
    public void saveToFile(String addressFile) throws IOException  {
        FileWriter fw = new FileWriter(new File(addressFile));
        generateXML(fw);
        fw.close();
    }

    /**
     * Save to data file
     */
    public void save() throws IOException  {
        saveToFile(adressFileName);
    }

    /**
     * Return a String with the XML representation of this instance
     *
     * @return a String with the XML representation of this instance
     */
    public String toString() {
        StringWriter sw = new StringWriter();
      //load();
        generateXML(sw);

       return sw.toString();
    }

	/*
	 * Add all methods that are neccessary for the program 
	 */
    public void load() throws XMLStreamException
    {
       
          XMLInputFactory inputFactory = XMLInputFactory.newInstance();
        XMLEventReader eventReader = inputFactory.createXMLEventReader(new StreamSource(new File(adressFileName)));
        Stack<String> stack = new Stack<String>();
        Address newAddress = null;
        
        while (eventReader.hasNext())
        {
            XMLEvent event = eventReader.nextEvent();
            if (event.isStartElement())
            {
                StartElement se = event.asStartElement(); //casting
                stack.push(se.getName().getLocalPart());
                if (stack.peek().equals("address"))
                    newAddress = new Address();
            }

            if (event.isCharacters())
            {
                Characters c = event.asCharacters(); //casting
                String s = c.getData();
                
                if (s.trim().length() > 0)
                {
                    
                        if( stack.peek().equals("forename"))
                            newAddress.setForename(s);
                           
                        if( stack.peek().equals("surename"))
                            newAddress.setSurname(s);
                        if( stack.peek().equals("email"))
                            newAddress.setEmail(s);
                }   
            }
            
            if (event.isEndElement())
                if (stack.pop().equals("address"))
                        addresses.add(newAddress);
        }
    
    }
    public void generateXML(Writer sw)
    {
     try{
            XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();
            XMLEventWriter eventWriter = outputFactory.createXMLEventWriter(sw);
            XMLEventFactory eventFactory = XMLEventFactory.newInstance();

            eventWriter.add(eventFactory.createStartDocument());
            eventWriter.add(eventFactory.createCharacters("\n"));
            eventWriter.add(eventFactory.createStartElement("", "", "addressbook"));
            eventWriter.add(eventFactory.createCharacters("\n"));
            Characters indent= eventFactory.createCharacters("    ");
            Characters newLine= eventFactory.createCharacters("\n");
            Iterator<Address> it = addresses.iterator();
            while (it.hasNext()) {
                Address newAddress = it.next();

                eventWriter.add(indent);
                eventWriter.add(eventFactory.createStartElement("", "", "address"));
                eventWriter.add(newLine);
                eventWriter.add(indent);
                eventWriter.add(indent);
                eventWriter.add(eventFactory.createStartElement("", "", "forename"));
                eventWriter.add(eventFactory.createCharacters(newAddress.getForename()));
                eventWriter.add(eventFactory.createEndElement("", "", "forename"));
                eventWriter.add(newLine);
                eventWriter.add(indent);
                eventWriter.add(indent);
                eventWriter.add(eventFactory.createStartElement("", "", "surename"));
                eventWriter.add(eventFactory.createCharacters(newAddress.getSurname()));
                eventWriter.add(eventFactory.createEndElement("", "", "surename"));
                eventWriter.add(newLine);
                eventWriter.add(indent);
                eventWriter.add(indent);
                eventWriter.add(eventFactory.createStartElement("", "", "email"));
                eventWriter.add(eventFactory.createCharacters(newAddress.getEmail()));
                eventWriter.add(eventFactory.createEndElement("", "", "email"));
                eventWriter.add(newLine);
                eventWriter.add(indent);
                eventWriter.add(eventFactory.createEndElement("", "", "address"));
                eventWriter.add(newLine);
            }

            eventWriter.add(eventFactory.createEndElement("", "", "addressbook"));
            eventWriter.add(newLine);
            eventWriter.add(eventFactory.createEndDocument());
            eventWriter.close();

     } 
     catch (Exception ex) {
            System.out.println(ex.getMessage());
    }
    }

    
    }
