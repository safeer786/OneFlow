/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author G510
 */


public class Address {

    private String forename;
    private String surname;
    private String email;

    public Address()  {}
    
    public Address(String forename, String surname, String email) {
        this.forename = forename;
        this.surname = surname;
        this.email = email;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getForename() {
        return this.forename;
    }

    public String getSurname() {
        return this.surname;
    }

    public String getEmail() {
        return this.email;
    }

    public boolean equals(Object anotherObject)  {
        boolean result = false;        

        if (getClass().equals(anotherObject.getClass()))  {            

            Address anotherAddress = (Address) anotherObject;            

            result = getForename().equalsIgnoreCase(anotherAddress.getForename()) &&
                     getSurname().equalsIgnoreCase(anotherAddress.getSurname());
        }
        
        return result;
    }

    public String toString() {
        return "[ Forename:"+forename+" Surename: "+surname+" Email: "+email+" ]";
    }
}
