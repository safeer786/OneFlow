/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author G510
 */
public class lab6 {
     public static void main(String[] args) {
        // TODO code application logic here
         SimpleSet<Integer> s=new LinkedSet();
         SimpleSet<Integer> s1=new LinkedSet();
         LinkedSet<Integer> s2=new LinkedSet();
          boolean a=s.add(1);
         System.out.println("s");
         a=s1.add(1);
         a=s1.add(2);
         a=s2.add(1);
         a=s2.add(2);
         a=s1.add(3);
         a=s.add(2);
         a=s.add(3);
         System.out.println(s.size());
         System.out.println(s);
        System.out.println(a=s.add(3));
         System.out.println(s.size());
         System.out.println(s);
         System.out.println("equals" + s.equals(s1));
         System.out.println("remove" + s2.remove(2));
         System.out.println(s2);
         System.out.println("remove" + s2.remove(2));
         System.out.println(s);
         
         
    }
}
