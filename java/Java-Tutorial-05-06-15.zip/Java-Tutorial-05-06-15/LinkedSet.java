/*
 * LinkedSet.java
 *
 * Created on May 22, 2006, 11:59 AM
 *
 * This class implements the SimpleSet interface  with a singly linked list
 */

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * The LinkedSet class implements the SimpleSet interface  with a singly linked list. 
 * @author saile
 */
public class LinkedSet<E> implements SimpleSet<E>{
    /*
     * head of the list
     */
    private ListNode head;
    /*
     * last node in list
     */
    private ListNode last;
    /*
     * number of elements in list
     */
    private int numElements;
    
    /** Creates a new instance of LinkedSet */
    public LinkedSet() {
        head = last = null;
    }
    
    /**
     * Adds the specified element to this set if it is not already present.
     * @param o element to be added to this set.
     * @return  true if this set did not already contain the specified element.
     * @throws NullPointerException - if the specified element is null and this set does not support null elements.
     */
    public boolean add(E o)  {
        ListNode temp=new ListNode(o,null);
        if(isEmpty())
        {
            head=temp;
            last=temp;
            numElements++;
        }
        else
        {
        
                    if(!contains(o))
            {
                last.next=temp;
                last = temp;
                numElements++;
            }
            else
            {
                return false;
            }
        }
        return true;
        
    }
    
    /**
     * Compares the specified object with this set for equality. 
     * @param o   Object to be compared for equality with this set.
     * @return true if the specified Object is equal to this set otherwise false.
     */
    public boolean equals(Object o)  {
         if ( o instanceof LinkedSet )
         {
             return equals( (LinkedSet)o );
        }
         else
             return false;
	}
    public boolean equals(LinkedSet o)
    {
        
        ListNode curr=o.head;
        if(o.size()==size())
        {
            for(curr=o.head;curr!=null;curr=curr.next)
            {
                if(!contains(curr.data))
                {
                    return false;
                }
            }
            return true;
        }
        return false;
            
        
    }
    
    /**
     * Removes the specified element from this set if it is present .
     * @param o  object to be removed from this set, if present.
     * @return true if the set contained the specified element otherwise false.
     */
    public boolean remove(E o)  {
        if(contains(o))
        {
            ListNode curr;
            ListNode prev=head;
            for(curr=head;curr.data!=o;curr=curr.next)
            {
               prev=curr;
            }
            if(curr.next==null)
            {
                prev.next=null;
                last=prev;
            }
            else
            {
                prev.next=curr.next;
            }
        }
        else
        {
            return false;
        }
        numElements--;
        return true;
    }
    
    /**
     * Returns an iterator over the elements in this set.
     * @return an iterator over the elements in this set.
     */
    public Iterator<E> iterator()  {
       return new LinkedSetIterator();
    }
    
    /**
     * Returns the number of elements in this set.
     * @return the number of elements in this set.
     */
    public int size()  {
        return numElements;
    }
    
    /**
     * Returns true if this set contains no elements.
     * @return true if this set contains no elements.
     */
    public boolean isEmpty() {
       return head == null;
      
    }
    
    /**
     * Returns true if this set contains the specified element.
     * @param o element whose presence in this set is to be tested.
     * @return true if this set contains the specified element otherwise false.
     */
    public boolean contains(Object o)  {
        if(!isEmpty())
        {
                  ListNode curr=head;
                  for(curr=head;curr!=null;curr=curr.next)
                  {
                      if(curr.data.equals(o))
                      {
                          return true;
                      }
                  }
        }
        return false;
    }
    
    
    /**
     * Return a String representing the LinkedSet<E>.
     * @return a String representing the LinkedSet.
     */
    public String toString() {
        ListNode curr;
        String r="";
        for(curr=head;curr!=null;curr=curr.next)
        {
            r=r+curr.data;
        }
        return r;
    }
    
    /////////////////////////////////////////////////////////
    
    /*
     * This class implements a node in a linked list data structure
     */
    
    private class ListNode {
        private E data;
        private ListNode next;
        
        public ListNode()  {
            data = null;
            next = null;
        }
        
        public ListNode(E element, ListNode link)  {
            data = element;
            next = link;
        }
    }
    
    /*
     * This class implements an iterator class for LinkedSet
     */
    
    private class LinkedSetIterator implements Iterator<E>  {
        ListNode currentNode; // Pointer to current node.
        
        public LinkedSetIterator()
        {
         currentNode=head;
        }
        
        public E next() 
        { 
          return currentNode.data;                      
        }
        
        public boolean hasNext()
        {
            if(currentNode.next != null)
            {
                return true;
            }
            return false;
        }
        
        public void remove()
        {
            throw new UnsupportedOperationException(); // remove() not supported.
        }
        
    }    
}