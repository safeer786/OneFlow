import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class PatientTest extends TestCase {
  
  
  
  
  
  
    
   /**
     * Test when both have default values;
     * expects true
     */
  
      public void testbothnull() {
         Patient p1 = new Patient();
         Patient p2 = new Patient();
         assertTrue(p1.equals(p2));
    }
  
     public void testvalidSsn() {
         Patient p1 = new Patient("saf","000-00-0000");                  
         assertTrue(p1.isValidSsn("000-00-0000"));
    }
          public void testvalidSsn1() {
         Patient p1 = new Patient("saf","000-00-0000");                  
         assertFalse(p1.isValidSsn("000000-0000"));
    }
  
  
  
  
    /**
     * Test default constructor.
     * 
     */
    public void testDefaultConstructor() {
         Patient p1 = new Patient();
         assertEquals("No name yet.",p1.getName());
         assertEquals("000-00-0000",p1.getSsn());
    }
    
    /**
     * Test name only constructor.
     * 
     */
    public void testNameConstructor() {
         Patient p1 = new Patient("English");
         assertEquals("English",p1.getName());
         assertEquals("000-00-0000",p1.getSsn());
    }
    
    /**
     * Test name and ssn constructor.
     * 
     */
    public void testNameSSNConstructor() {
         Patient p1 = new Patient("Yosarian","777-77-7777");
         assertEquals("Yosarian",p1.getName());
         assertEquals("777-77-7777",p1.getSsn());
    }
    
    /**
     * Test toString() method.
     * 
     */
    public void testtoString() {
         Patient p1 = new Patient("Yosarian","777-77-7777");
         assertEquals("Name: Yosarian;Ssn: 777-77-7777",p1.toString());         
    }
    
    /**
     * Test 2 patients for equality.
     * 
     */
    public void testPatientEqual() {
         Patient p1 = new Patient("Yosarian","777-77-7777");
         Patient p2 = new Patient("Yosarian","777-77-7777");
         assertTrue(p1.equals(p2));         
    }
    
     /**
     * Test 2 patients for inequality. (different name)
     * 
     */
    public void testPatientNotEqual() {
         Patient p1 = new Patient("Yosarian","777-77-7777");
         Patient p2 = new Patient("English","777-77-7777");
         assertFalse(p1.equals(p2));         
    }
    
    /**
     * Test 2 patients for inequality. (different ssn)
     * 
     */
    public void testPatientNotEqual2() {
         Patient p1 = new Patient("Yosarian","777-77-7777");
         Patient p2 = new Patient("Yosarian","777-77-7776");
         assertFalse(p1.equals(p2));         
    }
    
    /**
     * Test 2 patients for inequality. (Different class)
     * 
     */
    public void testPatientNotEqual3() {
         Patient p1 = new Patient("Yosarian","777-77-7777");
         
         assertFalse(p1.equals("English"));         
    }
}
