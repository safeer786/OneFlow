import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class Patient1Test extends TestCase {
  public void testexception()
  {
     try  {
            Patient1 p1 = new Patient1("Jim Knopf","a23-45-6789");
            fail();
      //      throw new IllegalSsnException ("Exception : Not valid Ssn");
            //fail();  // Fail because no exception was thrown
        }
        catch (IllegalSsnException e)  {
      
// Do nothing.   
        }
  }
    public void testexception1()
  {
     try  {
            Patient1 p1 = new Patient1("Jim Knopf","123-45-6789");
           // fail();
      //      throw new IllegalSsnException ("Exception : Not valid Ssn");
            //fail();  // Fail because no exception was thrown
        }
        catch (IllegalSsnException e)  {
      fail();
// Do nothing.   
        }
  }
}