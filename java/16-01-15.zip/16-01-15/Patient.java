import java.util.*;
public class Patient extends Person
{
 //   private String name;
    private String ssn; 
    
    public Patient() {
        super();                   //parent default constructor
        ssn ="000-00-0000";       //default ssn
    }
    //constructor with only name
    public Patient(String aName)
    {
    super(aName);
    ssn="000-00-0000";
    }
    //constructor with name and ssn
    public Patient(String aName,String aSsn)    //throws IllegalSsnException
    {
      
      super(aName);
      try{
      if(isValidSsn(aSsn))
      {
        ssn=aSsn;
      }
      else
      {
        throw new IllegalSsnException ("Exception : kk Not valid Ssn");
      }
      }
       catch(Exception e)
      {
        
       System.err.println("IllegalSsnException: " + e.getMessage());
      System.err.println("Ssn not valid set to default value 000-00-0000");
      ssn="000-00-0000";
      }
     
      
    }
    /**
     Set this patient's ssn.
     */
    public void setSsn(String newSsn)
    {
      ssn=newSsn;
    }
    public boolean isValidSsn(String aSsn) //throws IllegalSsnException
    {
     // String expression = "^\\d{3}[- ]?\\d{2}[- ]?\\d{4}$"; 
      if(aSsn.matches("^\\d{3}[- ]?\\d{2}[- ]?\\d{4}$")){  
     return true;  
       }  
      else
      {
      //  try {
       // throw new IllegalSsnException ("Exception : kk Not valid Ssn"); 
      
     //   }
     
        
        return false;
      }
    }
     /**
     Get this patient's ssn.
     @return this patient's ssn
     */
    public String getSsn()
    {
      return ssn;
    }
    public boolean equals(Object otherObj)
    {
      boolean result;      //for comparing name
      boolean result1;     //for comparing ssn
      result=false;
      result1=false;
      if (otherObj == null && this != null) {
            return false;
        }
        if (this.getClass() != otherObj.getClass()) {
            return false;
        }
        if(otherObj == null && this == null)
        {
          return true;
        }
        Patient otherPatient = (Patient) otherObj;
        result=super.equals(otherPatient);              //compare name by calling parent equal method
        result1= ssn.equals(otherPatient.getSsn());
        if(result==true && result1==true)
        {
          return true;
        }
        else
        {
          return false;
        }
    }
     /**
     Get a string representation of this patient.
     
     @return a string representation of this in person class and then add ssn
     */
    public String toString()  {
        return super.toString()+";Ssn: "+ssn;
    }
}