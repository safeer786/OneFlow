public class IllegalSsnException extends Exception
{
    public IllegalSsnException()
    {
        super("Illegal Ssn ");
    }
    
    public IllegalSsnException(String message)
    {
        super(message);
    }
}
