/**
  
   File name: PatientTest.java
  
   This program tests Patient class.  
*/
import java.util.*;

public class PatientTestDemo
{
   public static void main(String[] args)
   {
      Scanner keyboard = new Scanner(System.in);
      char repeat;
      String aSsn="000-00-0000";

      do  // repeat if user says 'yes'
      {
         // Test the constructors (uses writeOutput method)
         Patient p = new Patient("safff","1111-11-1111");
         p.isValidSsn("1111-11-1111");
         System.out.println(p.getSsn());
         p.isValidSsn("a11-11-1111");
         Patient p1 = new Patient();
         System.out.println("Test default constructor & writeOutput:");
         System.out.println();
         System.out.println("Verify:");
         System.out.println("Name: No name yet.");
         System.out.println("SSN: 000-00-0000");
         System.out.println(aSsn.substring(3,4) + aSsn.substring(6,7) + aSsn.length());
         
         System.out.println();
         System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         System.out.println("===============================");

   // Test the name only contructor
         System.out.println("Test constructor with just name:");
         Patient p2 = new Patient("English");
         System.out.println();
         System.out.println("Verify:");
         System.out.println("Name: English.");
         System.out.println("SSN: 000-00-0000");
         System.out.println();
         System.out.println(p2.getName());
   System.out.println(p2.getSsn());
         System.out.println();
         System.out.println("===============================");

   // Test constructor with name and SSN
   
         System.out.println("Test constructor with both name & SSn:");
         Patient p3 = new Patient("Yosarian", "777-77-7777");
         System.out.println();
         System.out.println("Verify:");
         System.out.println("Name: Yosarian.");
         System.out.println("SSN: 777-77-7777");
         System.out.println();
       System.out.println(p3.getName());
   System.out.println(p3.getSsn());  
         System.out.println();
         System.out.println("===============================");

   
         // Test methods to change, return and write values

         // change all
         System.out.println("Test to change name & SSN:");
         System.out.println();
         System.out.println("Before:");
     System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         p1.setName("Brabanek");
   p1.setSsn("111-11-1111");
         System.out.println("Verify:");
         System.out.println("Name: Brabanek.");
         System.out.println("SSN: 111-11-1111");
         System.out.println();
         System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         System.out.println("===============================");

   
         System.out.println("Test to change name:");
         System.out.println();
         System.out.println("Before:");
         System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         p1.setName("Faith");
         System.out.println("Verify:");
         System.out.println("Name: Faith.");
         System.out.println("SSN: 111-11-1111");
         System.out.println();
         System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         System.out.println("===============================");

         System.out.println("Test to change SSN:");
         System.out.println();
         System.out.println("Before:");
     System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         p1.setSsn("222-22-2222");
         System.out.println("Verify:");
         System.out.println("Name: Faith.");
         System.out.println("SSN: 222-22-2222");
         System.out.println();
         System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         System.out.println("===============================");

         System.out.println("Test to return name:");
         System.out.println();
         System.out.println("Verify:");
         System.out.println("Name: Faith.");
         System.out.println();
         System.out.println(p1.getName());
         System.out.println();
         System.out.println("===============================");

         System.out.println("Test to return SSN:");
         System.out.println();
         System.out.println("Verify:");
         System.out.println("SSN: 222-22-2222");
         System.out.println();
         System.out.println(p1.getSsn());
         System.out.println();
         System.out.println("===============================");
         System.out.println();
         System.out.println();

         System.out.println("First equals test:");
         System.out.println();
         //Create 2nd Patient with same instance values.
         Patient p4 = new Patient("Faith", "222-22-2222");
         System.out.println();
         System.out.println("First patient's values:");
         System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         System.out.println("Second patient's values:");
         System.out.println(p4.getName());
   System.out.println(p4.getSsn());
         System.out.println();
         System.out.println("Verify: true.");
         System.out.println();
         System.out.println(p1.equals(p4));
         System.out.println();
         System.out.println();
         System.out.println("===============================");

         // create a single char difference in SSN
         System.out.println();
         p4.setSsn("222-22-222");
         System.out.println("After changing just one character"
                + " in the social security number,");
         System.out.println("the data for the 2 partients are");
         System.out.println();
         System.out.println("First patient:");
         System.out.println(p1.getName());
   System.out.println(p1.getSsn());
         System.out.println();
         System.out.println("Second patient:");
         System.out.println(p4.getName());
   System.out.println(p4.getSsn());
         System.out.println();
         System.out.println("Verify: false.");
         System.out.println();
         System.out.println(p1.equals(p4));
         System.out.println();
   System.out.println("===============================");
   // Test toString() method
   
   System.out.println();
   System.out.println("Testing toString()");
   System.out.println();
   System.out.println("Verify: Name: Faith;Ssn: 222-22-222");  
   System.out.println();
   System.out.println(p4.toString());
   System.out.println();
         System.out.println("===============================");
   
         System.out.println("Do again? (Y for Yes, or N for No)");
         repeat = keyboard.next().charAt(0);

      }while((repeat == 'y') || (repeat == 'Y'));
   }
}
