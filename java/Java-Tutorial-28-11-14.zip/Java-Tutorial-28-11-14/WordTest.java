import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class WordTest extends TestCase {
    protected Word word1;
    protected Word word2;
    protected Word word3;
    

    /*
     * Setup test environment
     */
    protected void setUp() {
        
        /*
         * A simple, innocent word...
         */
        word1 = new Word();
        word1.setWord("ponies");
        
        /* 
         * Create a word with the default constructor, then initialize instance
         * with setWord()
         */
        word2 = new Word();            
        word2.setWord("motoring");            
         
        
        /*
         * Default constructor; No initialization 
         */        
        word3 = new Word();
    }
    
    /*
     * Throw away all the words...
     */
    protected void tearDown() {          
      word1 = null;
      word2 = null;
      word3 = null;
    }
    
    
    /**
     * test getWord() method.
     */
    public void testGetWord() {
       assertNotNull("word1 not null",word1);
       assertEquals("ponies",word1.getWord());
       assertEquals("GetWord word2","motoring",word2.getWord());
       assertEquals("",word3.getWord());       
    }
    /**
     * test getStem() method.
     */
    public void testGetStem() {
       assertEquals("pony",word1.getStem());
       assertEquals("motor",word2.getStem());
       assertEquals("",word3.getStem());
    }
    /**
     * test getSyllableCnt() method.
     */
    public void testGetSyllableCnt() {
       assertEquals(2,word1.getSyllableCnt());
       assertEquals(3,word2.getSyllableCnt());
       
       assertEquals(0,word3.getSyllableCnt());
    }
}
