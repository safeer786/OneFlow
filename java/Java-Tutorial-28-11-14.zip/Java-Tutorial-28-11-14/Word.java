/**
 A class to store words, with methods to get
 the word, the stem of the word, and the number
 of syllables in the word.
 */
public class Word {
  
  private String word;
  private int sylc;
  private String stem;
  /*
    * Instance variables. Initialized to default values.
    */
  public Word()
  {
    word="";
    sylc=0;
    stem="";
  }
   /**
    Set word to new value newWord.
    
    @param newWord - The new value of word
    */
  public Word(String aWord)
  {
    word=aWord;
  }
   /**
    * calls createSyllablecnt 
    @param word
    * @return The syllable of the word
    */
  
  public int getSyllableCnt()
  {
    sylc=createSyllableCnt(word);
    return sylc;
  }
   /**
    * Returns the  word 
    *
    * @return the word
    */
  
  public String getWord()
  {
    return word;
  }
  
   
   /**
    Set word to new value newWord.
    
    @param newWord - The new value of word
    */
   
   public void setWord(String newWord)
   {
         word=newWord;
         stem=getStem();
         sylc=getSyllableCnt();
//      System.out.println("You better write an implementation of this method");
   }
   
   /**
    * Returns the stem of the word 
    *
    * @return The stem of the word
    */
   public String getStem() {
          stem=createStem(word);
          return stem;

   }
   private int createSyllableCnt(String aWord)
   {
boolean previous = false;
boolean current = false;
int sc = 0;

/*
 * Empty word has no syllables
 */
if (aWord.length() == 0)
 return 0;
         
for (int i = 0; i < aWord.length(); i++) {
 // Determine if this char is a vowel
 if((aWord.charAt(i) == 'a') || (aWord.charAt(i) == 'e')|| (aWord.charAt(i) == 'i')|| (aWord.charAt(i) == 'o')|| (aWord.charAt(i) == 'u')|| (aWord.charAt(i) == 'y'))
 {
   current=true;
 }
 else
 {
   current=false;
 }
  

 // Only increment syllableCnt if the previous char
 // was NOT a vowel
 if (current && !previous) {
  sc++;
 }

 // Update lastWasVowel for the next iteration
 previous = current;
}

// A trailing 'e' would have been counted as a syllable
// when it shouldn't have been
if (aWord.endsWith("e")) {
 sc--;
}

// All words have at least 1 syllable
if (sc <= 0) {
 sc = 1;
}

return sc;
   }
   private String createStem(String aWord)
   {
     String theStem;
int len = aWord.length();
if (aWord.endsWith("ing") && len>4) {
 theStem = aWord.substring(0,len-3);
}
else if (aWord.endsWith("sses"))  {
 theStem = aWord.substring(0,len-2);
}
else if (aWord.endsWith("ies")) {
 theStem = aWord.substring(0,len-3)+"y";
}
else if (aWord.endsWith("ss"))  {
 theStem = aWord;
}
else if (aWord.endsWith("s"))  {
 theStem = aWord.substring(0,len-1);
}
else if (aWord.endsWith("eed") && len > 4) {
 theStem = aWord.substring(0,len-1);
}
else if (aWord.endsWith("ed") && len > 4) {
 theStem = aWord.substring(0,len-2);
}
else {
 theStem = aWord;
}

return theStem;
   }
}
