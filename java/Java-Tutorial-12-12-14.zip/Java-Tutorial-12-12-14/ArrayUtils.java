import java.lang.Object;
public class ArrayUtils
  extends Object {
   /**
   concatinate array1 and array2 to new array
   * @param array1 array2
   * 
   *@return conarr
   */

  static Object[]  concatArrays(Object[] array1, Object[] array2) 
  {
    Object[] conarr;
    //new array of size of array1 and array2
    conarr = new Object [array1.length +array2.length];
    //copy array1 elements to new array
  
    for(int i=0;i<array1.length ;i++)
    {
      conarr[i]=array1[i];
    }
    
    int j=array1.length;
    //now copy array2 elements to new array
    for(int k=0;k<=array2.length - 1;k++)
    {
      conarr[j]=array2[k];
      j++;
    }
    return conarr;
  }
  /**
   Reverse elements of anArray in new array 
   * @param anArray
   * 
   *@return revarr
   */
   static Object[]  reverseArray(Object[] anArray) 
   {
     int j=0;
     Object[] revarr;
    revarr = new Object [anArray.length];
    //copy anArray elements in reverse order
    for(int i=anArray.length - 1;i>=0;i--)
    {
      revarr[j]=anArray[i];
      j++;
    }
    return revarr;
   }
     public ArrayUtils()
  {;}
   /**
   Search for aObject in anArray
   * @param anArray aObject
   * 
   *@return index
   */
    static int  searchArrayForAnObject(Object[] anArray, Object aObject) 
    {
      int index=-1;
      int i=0;
      boolean found=false;
      //if find set index to i
      while(!found && i<=anArray.length-1)
      {
        if(anArray[i]==aObject)
        {
          index=i;
          found=true;
        }
        i++;
      }
      return index;
    }
}