import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class ArrayUtilsTest extends TestCase {
  
  /**
   * Test reverseArray(). Expect success
   *
   */
  public void testReverseArray() {
    String[] a1={"AA","BB","CC","DD","EE"};
    String[] expected={"EE","DD","CC","BB","AA"};
    Object[] res = ArrayUtils.reverseArray(a1);   
    assertTrue(expected.length == res.length);
    for (int i=0;i<res.length;i++)  {
      assertEquals(res[i],expected[i]);
    }
  }
  /**
   * Test reverseArray() for empty . Expect success
   *
   */
  
    public void testReverseArray1() {
      String[] a1={""};
      String[] expected={""};
    Object[] res = ArrayUtils.reverseArray(a1);   
    assertTrue(expected.length == res.length);
    for (int i=0;i<res.length;i++)  {
      assertEquals(res[i],expected[i]);
    }
  }
    /* More tests after this comment.... */
  /**
   * Test searchArray() middle element. Expect success
   *
   */
  
    public void testSearchArray() {
    String[] a1={"AA","BB","CC","BB","BB"};
    int i=2;
    //String[] expected={"EE","DD","CC","BB","AA"};
    int j=ArrayUtils.searchArrayForAnObject(a1,"CC");   
    assertTrue(j == i);
     }
    /* More tests after this comment.... */
  /**
   * Test searchArray() first element. Expect success
   *
   */
  
    public void testSearchArray2() {
    String[] a1={"AA","BB","CC","BB","BB"};
    int i=0;
    //String[] expected={"EE","DD","CC","BB","AA"};
    int j=ArrayUtils.searchArrayForAnObject(a1,"AA");   
    assertTrue(j == i);
     }
    
   /* More tests after this comment.... */
  /**
   * Test searchArray() last element. Expect success
   *
   */
  
    public void testSearchArray3() {
    String[] a1={"AA","BB","CC","BB","DD"};
    int i=4;
    //String[] expected={"EE","DD","CC","BB","AA"};
    int j=ArrayUtils.searchArrayForAnObject(a1,"DD");   
    assertTrue(j == i);
     }

  /* More tests after this comment.... */
  /**
   * Test searchArray() not found element. Expect success
   *
   */    
    public void testSearchArray1() {
    String[] a1={"AA","BB","CC","BB","BB"};
    int i=-1;
    //String[] expected={"EE","DD","CC","BB","AA"};
    int j=ArrayUtils.searchArrayForAnObject(a1,"EB");   
    assertTrue(j == i);
     }
    
    
   /**
   * Test concatinateArray(). Expect success
   *
   */
  
    
     public void testConcatinateArray() {
    String[] a1={"AA","BB","CC","DD","EE"};
    String[] a2={"AAA","BBB","CCC","DDD","EEE"};
    String[] expected={"AA","BB","CC","DD","EE","AAA","BBB","CCC","DDD","EEE"};
    Object[] res = ArrayUtils.concatArrays(a1,a2);   
    assertTrue(expected.length == res.length);
    for (int i=0;i<res.length;i++)  {
      assertEquals(res[i],expected[i]);
    }
  }
   /**
   * Test concatinateArray() first empty. Expect success
   *
   */
  
    
     public void testConcatinateArray1() {
    String[] a1=new String[0];
    String[] a2={"AAA","BBB","CCC","DDD","EEE"};
    String[] expected={"AAA","BBB","CCC","DDD","EEE"};
    Object[] res = ArrayUtils.concatArrays(a1,a2);   
    assertTrue(expected.length == res.length);
    for (int i=0;i<res.length;i++)  {
     // assertEquals(res[i],expected[i]);
      System.out.println(res[i]+expected[i]);
    }
  }     
   /**
   * Test concatinateArray2() second array empty. Expect success
   *
   */
  
    
    public void testConcatinateArray2() {
    String[] a1={"AA","BB","CC","DD","EE"};
    String[] a2=new String[0];
    String[] expected={"AA","BB","CC","DD","EE"};
    Object[] res = ArrayUtils.concatArrays(a1,a2);   
    assertTrue(expected.length == res.length);
    for (int i=0;i<res.length;i++)  {
      assertEquals(res[i],expected[i]);
    }
  }
  
}
