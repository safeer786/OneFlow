package com.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
 
public class DataHandler {
	public static Connection getdbConnection()
	{
    	Connection conn=null;
    
    	try {
    		Class.forName("oracle.jdbc.driver.OracleDriver");
	    	conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "electionManagement", "admin");
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}

     return conn;
    }
}
