package com.login;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.db.DataHandler;
/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		Connection conn=DataHandler.getdbConnection();
		Statement stmt =null;
		ResultSet rs = null;
		String sql="select *from logins where username='"+uname+"' and password='"+pass+"'";
		
		try
		{
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			if(rs.next())
			{
				HttpSession session=request.getSession();
				session.setAttribute("uname", uname);
				response.sendRedirect("vote.jsp");
			}
			else
			{
				response.sendRedirect("index.jsp");
			}
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		
		
	}


}
