package com.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.db.DataHandler;

/**
 * Servlet implementation class vote
 */
@WebServlet("/vote")
public class vote extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
   		if (request.getSession().getAttribute("uname")==null)
   		{
   			response.sendRedirect("login.jsp");
   		}
		String uname= (String) request.getSession().getAttribute("uname");
		String value=request.getParameter("party");
		Connection conn=DataHandler.getdbConnection();
		Statement stmt =null;
		ResultSet rs = null;
		String sql="INSERT INTO vote (username,vote) VALUES(?,?)";
		 
		try
		{
			PreparedStatement pst =(PreparedStatement) conn.prepareStatement("insert into vote (username,party) values(?,?)");
			pst.setString(1,uname);  
	        pst.setString(2,value);	
	        int i=pst.executeUpdate();
	        if(i!=0)
	        {
	        	response.sendRedirect("end.jsp");
	        }
	        
	        
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
