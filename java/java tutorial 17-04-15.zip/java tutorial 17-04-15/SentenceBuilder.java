class SentenceBuilder{
  private ArrayList a;
  public SentenceBuilder(String fileName)
  {
    //done in the arraylist class
    a.read(fileName);
  }
  public ArrayList next()
  {
    //done in the arraylist class
   return a.next();
  }
  public boolean hasnext()
  {
    //done in the arraylist class
    return(a.hasnext());
  }
  
}