import java.io.*;
import java.util.*;
class ArrayList{
   // private int countOfEntries; //can be less than entry.length.
   public static final int DEFAULT_SIZE = 1000; 
  private String[] entry;
  private int count; //counter for the list of words in the sentence and initial size is like 1000
  private int pos; //counter for the postion in the next method 
    public ArrayList()
  {
    entry=new String [DEFAULT_SIZE];
    pos=0;
    count=0;
    
  }
    public void read(String fileName)
    {
      //read the whole file and store the sentences in the arraylist 
      //only the sentences with also the words #BOS and #EOS
      String file=fileName;
     String line;
     int count=0;
     String[] words=new String[8];
    // String[] 
     BufferedReader src1;
     String encoding="UTF-8";
     int fre;
    // BufferedReader src2;
     //NameFrequency obj;
  //blist=new NoRepeatsList();
  //glist=new NoRepeatsList();
  try 
  {
    src1 = new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8"));
    while ((line = src1.readLine()) != null)
    {
          words = line.split("\\s+");
          if(words[0].equals("#BOS"))
          {
            for(int i=0;i<8;i++)
            {
              entry[count]=words[i];
              count++;
            }
            while((line=src1.readLine()) !=null)
            {
              if(line.startsWith("#EOS"))
                   {
                entry[count]="#EOS";
                count++;
                break;
              }
              else if(line.startsWith("#"))
                   {;}
                 else{
              words = line.split("\\s+");
               for(int j=0;j<7;j++)
            {
              entry[count]=words[j];
              count++;
            }
                 }
             }
}
                
          
    
    }
  src1.close();
  }
    catch (FileNotFoundException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);        
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }

}
    //reads the list of word in a sentence and returns the arraylist 
    public ArrayList next()
    {
      ArrayList word=new ArrayList();
      int i=0;
        if(entry[pos].equals("#BOS"))
             {
          pos++;
          while(!entry[pos].equals("#EOS"))
                  {
            word.entry[i]=entry[pos];
            i++;
            pos++;
          }
          pos++;

      }
           return word;
           }
    //checks the sentence exists or not 
    public boolean hasnext()
    {
      if(pos==count)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
}