package net.sei.jaas.ourmood.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.sei.jaas.ourmood.model.Team;
import net.sei.jaas.ourmood.repository.TeamRepository;
@Service
public class TeamServiceImpl implements TeamService {

	@Autowired
	private TeamRepository teamRepository;
	
	public TeamRepository getTeamRepository() {
		return teamRepository;
	}

	public void setTEamRepository(TeamRepository teamRepository) {
		this.teamRepository = teamRepository;
	}


	@Override
	public Team findById(long id) {
		Team team = teamRepository.getOne(id);
		return team;
	}


	@Override
	public List<Team> findAll() {
		List<Team> teams = teamRepository.findAll();
		return teams;
	}

	@Override
	public boolean isExist(Team team) {
		return teamRepository.exists(team.getId());
	}

	@Override
	public void update(Team team) {
		teamRepository.saveAndFlush(team);
	}

	@Override
	public Team save(Team team) {
		team = teamRepository.save(team);
		return team;
	}

	@Override
	public List<Team> getActiveTeams() {
		return teamRepository.findByActiveTrue();
	}

}
