package net.sei.jaas.ourmood.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChartData implements Serializable {

	public List<Date> getxData() {
		return xData;
	}
	public void setxData(List<Date> xData) {
		this.xData = xData;
	}
	
	
	public List<ChartYData> getyData() {
		return yData;
	}
	public void setyData(List<ChartYData> yData) {
		this.yData = yData;
	}


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Date> xData = new ArrayList<Date>();
	private List<ChartYData> yData = new ArrayList<ChartYData>();

}
