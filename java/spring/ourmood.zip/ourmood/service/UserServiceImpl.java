package net.sei.jaas.ourmood.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.sei.jaas.ourmood.model.User;
import net.sei.jaas.ourmood.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	

	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public User save(User user) {
		user = userRepository.save(user);
		return user;
	}

	@Override
	public List<User> findAll() {
		List<User> users = userRepository.findAll();
		return users;
	}

	@Override
	public User findById(long id) {
		User user = userRepository.getOne(id);
		return user;
	}

	@Override
	public boolean isExist(User user) {
		return userRepository.exists(user.getId());
	}

	@Override
	public void update(User user) {
		userRepository.saveAndFlush(user);
	}

	@Override
	public void deactive(User user) {
		user.setActive(false);
		update(user);
	}

	@Override
	public void reactive(User user) {
		user.setActive(true);
		update(user);
		
	}

	@Override
	public boolean isExist(long id) {
		return userRepository.exists(id);
	}
}
