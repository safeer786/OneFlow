package net.sei.jaas.ourmood.service;

import java.util.List;

import net.sei.jaas.ourmood.model.Team;


public interface TeamService {

	Team findById(long id);

	List<Team> findAll();

	boolean isExist(Team team);

	void update(Team team);

	Team save(Team team);

	List<Team> getActiveTeams();

}
