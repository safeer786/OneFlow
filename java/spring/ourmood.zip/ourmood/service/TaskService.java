package net.sei.jaas.ourmood.service;

import java.util.List;

import net.sei.jaas.ourmood.model.Team;
import net.sei.jaas.ourmood.model.Task;
import net.sei.jaas.ourmood.model.User;

public interface TaskService {

	Task findById(long taskId);

	void update(Task task);

	List<Task> findAllByUserAndIsNotAnswered(User user);

	ChartData getTeamChartData(Team team);

}
