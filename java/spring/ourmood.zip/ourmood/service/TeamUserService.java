package net.sei.jaas.ourmood.service;

import java.util.List;

import net.sei.jaas.ourmood.model.Team;
import net.sei.jaas.ourmood.model.TeamUser;
import net.sei.jaas.ourmood.model.User;

public interface TeamUserService {

	TeamUser getTeamUserByUser(User user);
	List<TeamUser> getActiveTeamUsers(Team team);

}
