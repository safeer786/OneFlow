package net.sei.jaas.ourmood.service;

import java.util.List;

import net.sei.jaas.ourmood.model.User;

public interface UserService {

	List<User> findAll();

	User findById(long id);

	User save(User user);

	boolean isExist(User user);

	void update(User currentUser);

	void deactive(User user);

	void reactive(User user);

	boolean isExist(long id);


}
