package net.sei.jaas.ourmood.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.sei.jaas.ourmood.model.Team;
import net.sei.jaas.ourmood.model.TeamUser;
import net.sei.jaas.ourmood.model.User;
import net.sei.jaas.ourmood.repository.TeamUserRepository;

@Service
public class TeamUserServiceImpl implements TeamUserService {

	@Autowired
	private TeamUserRepository teamUserRepository;

	public TeamUserRepository getTeamUserRepository() {
		return teamUserRepository;
	}

	public void setTeamUserRepository(TeamUserRepository teamUserRepository) {
		this.teamUserRepository = teamUserRepository;
	}

	@Override
	public TeamUser getTeamUserByUser(User user) {
		TeamUser teamUser = teamUserRepository.findByUser(user);
		return teamUser;
	}

	@Override
	public List<TeamUser> getActiveTeamUsers(Team team) {
		return teamUserRepository.findByActiveTrue();
	}

}
