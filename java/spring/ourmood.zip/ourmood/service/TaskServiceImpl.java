package net.sei.jaas.ourmood.service;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import net.sei.jaas.ourmood.model.Team;
import net.sei.jaas.ourmood.model.TeamUser;
import net.sei.jaas.ourmood.model.Task;
import net.sei.jaas.ourmood.model.User;
import net.sei.jaas.ourmood.repository.TaskRepository;
import net.sei.jaas.ourmood.repository.TeamRepository;
import net.sei.jaas.ourmood.util.Utils;

@Service
public class TaskServiceImpl implements TaskService {
	@Autowired
	private TaskRepository taskRepository;
	
	@Autowired
	private TeamService teamService;
	
	@Autowired
	private TeamUserService teamUserService;
	

	public TaskRepository getTaskRepository() {
		return taskRepository;
	}

	public void setTaskRepository(TaskRepository taskRepository) {
		this.taskRepository = taskRepository;
	}
	
	
	public TeamService getTeamService() {
		return teamService;
	}

	public void setTeamService(TeamService teamService) {
		this.teamService = teamService;
	}
	
	

	public TeamUserService getTeamUserService() {
		return teamUserService;
	}

	public void setTeamUserService(TeamUserService teamUserService) {
		this.teamUserService = teamUserService;
	}

	@Override
	public List<Task> findAllByUserAndIsNotAnswered(User user) {
		List<Task> tasks = taskRepository.findAllbyUserAndisNotAnswerd(user);
		return tasks;
	}

	@Override
	public Task findById(long taskId) {
		return taskRepository.getOne(taskId);
	}

	@Override
	public void update(Task task) {
		taskRepository.saveAndFlush(task);
	}

	@Override
	public ChartData getTeamChartData(Team team) {
		List<Task> answerdTasks = taskRepository.findAllbyTeamAndisAnswerd(team);
		ChartData chartData = getChartData(answerdTasks);
		return chartData;
	}

	private ChartData getChartData(List<Task> answerdTasks) {
		Collections.sort(answerdTasks);
		ChartData chartData = new ChartData();
		ChartYData yData = new ChartYData();
		List<Date> xDate = chartData.getxData();

		Date date = null;
		int index = -1;
		if (!answerdTasks.isEmpty()) {
			Task task = answerdTasks.get(0);
			date = task.getDate();
			xDate.add(date);
			yData.setName(task.getTeamUser().getTeam().getName());
			yData.getData().add(0D);
			index = 0;
		}
		Double answer = 0D;
		for (Task task : answerdTasks) {
			index = xDate.size() - 1;
			if (Utils.equalsDay(date, task.getDate())) {
				answer += task.getAnswer();
				yData.getData().set(index, answer);
			} else {
				date = task.getDate();
				xDate.add(date);
				yData.getData().add((double)task.getAnswer());
			}
		}
		List<Double> data = yData.getData();
		int size = data.size();
		for (int i = 0; i < size; i++) {
			data.set(i, (double) data.get(i)/ size);
		}

		chartData.getyData().add(yData);
		return chartData;

	}

	@Scheduled(cron = "0 0 15 ? * MON-FRI")
    public void createTasks() {
		List<Team> teams = teamService.getActiveTeams();
		for (Team team:teams) {
			List<TeamUser> teamUsers = teamUserService.getActiveTeamUsers(team);
			for (TeamUser teamUser: teamUsers) {
				addNewTasktoTeamUser(teamUser);
			}			
		}
    }
	
	private void addNewTasktoTeamUser(TeamUser teamUser) {
		Task task = new Task();
		task.setDate(new Date());
		task.setTeamUser(teamUser);
		taskRepository.save(task);
	}

}
