package net.sei.jaas.ourmood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import net.sei.jaas.ourmood.model.Team;
import net.sei.jaas.ourmood.model.Task;
import net.sei.jaas.ourmood.model.User;

public interface TaskRepository extends JpaRepository<Task, Long> {

	@Query("select t from Task t inner join t.teamUser tu inner join tu.user u where u = :user and t.answer = -1")
	List<Task> findAllbyUserAndisNotAnswerd(@Param("user") User user);

	@Query("select ta from Task ta inner join  ta.teamUser tu inner join tu.team t where t = :team AND ta.answer <> -1")
	List<Task> findAllbyTeamAndisAnswerd(@Param("team") Team team);

}
