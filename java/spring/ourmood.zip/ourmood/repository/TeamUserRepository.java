package net.sei.jaas.ourmood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.sei.jaas.ourmood.model.TeamUser;
import net.sei.jaas.ourmood.model.User;

public interface TeamUserRepository extends JpaRepository<TeamUser, Long> {

	TeamUser findByUser(User user);

	List<TeamUser> findByActiveTrue();

}
