package net.sei.jaas.ourmood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.sei.jaas.ourmood.model.Team;

public interface TeamRepository extends JpaRepository<Team, Long>{

	List<Team> findByActiveTrue();

}
