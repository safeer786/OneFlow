package net.sei.jaas.ourmood.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.sei.jaas.ourmood.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
   
}