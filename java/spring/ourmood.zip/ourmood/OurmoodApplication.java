package net.sei.jaas.ourmood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class OurmoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurmoodApplication.class, args);
	}
}
