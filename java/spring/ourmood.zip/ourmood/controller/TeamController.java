package net.sei.jaas.ourmood.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import net.sei.jaas.ourmood.model.Team;
import net.sei.jaas.ourmood.model.TeamUser;
import net.sei.jaas.ourmood.model.User;
import net.sei.jaas.ourmood.service.TeamService;
import net.sei.jaas.ourmood.service.UserService;

@RestController
@CrossOrigin
@RequestMapping("/teams")
public class TeamController {

	@Autowired
	private TeamService teamService;
	
	@Autowired
	private UserService userService;

	// -------------------Retrieve All
	// Teams--------------------------------------------------------

	public TeamService getTeamService() {
		return teamService;
	}

	public void setTeamService(TeamService teamService) {
		this.teamService = teamService;
	}
	
	

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ResponseEntity<List<Team>> listAllTeams() {
		List<Team> teams = teamService.findAll();
		if (teams.isEmpty()) {
			return new ResponseEntity<List<Team>>(HttpStatus.NO_CONTENT);// You many decide to return
																			// HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Team>>(teams, HttpStatus.OK);
	}

	// -------------------Retrieve Single
	// Team--------------------------------------------------------

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<Team> getTeam(@PathVariable("id") long id) {
		System.out.println("Fetching Team with id " + id);
		Team team = teamService.findById(id);
		if (team == null) {
			System.out.println("Team with id " + id + " not found");
			return new ResponseEntity<Team>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Team>(team, HttpStatus.OK);
	}

	// -------------------Create a
	// Team--------------------------------------------------------

	@RequestMapping(value = "/", method = RequestMethod.POST)
	public ResponseEntity<Void> createTeam(@RequestBody Team team, UriComponentsBuilder ucBuilder) {
		System.out.println("Creating Team " + team.getName());

		if (teamService.isExist(team)) {
			System.out.println("A Team with name " + team.getName() + " already exist");
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}

		teamService.save(team);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/teams/{id}").buildAndExpand(team.getId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

	// ------------------- Update a Team
	// --------------------------------------------------------

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Team> updateTeam(@PathVariable("id") long id, @RequestBody Team t) {
		System.out.println("Updating Team " + id);

		Team currentTeam = teamService.findById(id);

		if (currentTeam == null) {
			System.out.println("Team with id " + id + " not found");
			return new ResponseEntity<Team>(HttpStatus.NOT_FOUND);
		}

		currentTeam.setName(t.getName());
		currentTeam.setDescription(t.getDescription());

		teamService.update(currentTeam);
		return new ResponseEntity<Team>(currentTeam, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/{id}/add", method = RequestMethod.POST)
	public ResponseEntity<Void> addTeamUser(@PathVariable("team_id") long teamId, @PathVariable("user_id") long userId, 
			@RequestBody TeamUser tu, UriComponentsBuilder ucBuilder) {
		Team team = teamService.findById(teamId);
		User user = userService.findById(userId);
		TeamUser teamUser = new TeamUser();
		teamUser.setTeam(team);
		teamUser.setUser(user);
		teamUser.setActive(tu.isActive());
		teamUser.setAdmin(tu.isAdmin());
		teamUser.setRole(tu.getRole());
		team.getTeamusers().add(teamUser);
		teamService.save(team);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/teams/{id}").buildAndExpand(team.getId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	

}
