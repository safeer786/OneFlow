package net.sei.jaas.ourmood.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import net.sei.jaas.ourmood.model.Task;
import net.sei.jaas.ourmood.model.TeamUser;
import net.sei.jaas.ourmood.model.User;
import net.sei.jaas.ourmood.service.ChartData;
import net.sei.jaas.ourmood.service.TaskService;
import net.sei.jaas.ourmood.service.TeamUserService;
import net.sei.jaas.ourmood.service.UserService;;

@RestController
@CrossOrigin
@RequestMapping("/task")

public class MainController {
	@Autowired
	private TaskService taskService;

	@Autowired
	private TeamUserService teamUserService;
	@Autowired
	private UserService userService;

	public TaskService getTaskService() {
		return taskService;
	}

	public void setTaskService(TaskService taskService) {
		this.taskService = taskService;
	}

	public TeamUserService getTeamUserService() {
		return teamUserService;
	}

	public void setTeamUserService(TeamUserService teamUserService) {
		this.teamUserService = teamUserService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<List<Task>> listUserTasks(@PathVariable("id") long userId) {
		User user = userService.findById(userId);
		if (user == null) {
			return new ResponseEntity<List<Task>>(HttpStatus.NOT_FOUND);
		}

		ArrayList<Task> userTasks = (ArrayList<Task>) taskService.findAllByUserAndIsNotAnswered(user);
		if (userTasks.isEmpty()) {
			return new ResponseEntity<List<Task>>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<List<Task>>(userTasks, HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}/{value}", method = RequestMethod.POST)
	public ResponseEntity<Void> answer(@PathVariable("id") long taskId, @PathVariable("value") int value) {
		Task task = taskService.findById(taskId);
		if (task == null) {
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}
		task.setAnswer(value);
		taskService.update(task);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@RequestMapping(value = "/chart/{id}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<ChartData> getTeamChart(@PathVariable("id") long userId) {
		User user = userService.findById(userId);
		if (user == null) {
			return new ResponseEntity<ChartData>(HttpStatus.NOT_FOUND);
		}

		TeamUser teamUser = teamUserService.getTeamUserByUser(user);
		if (teamUser == null) {
			return new ResponseEntity<ChartData>(HttpStatus.NOT_FOUND);
		}

		ChartData answeredTasks = taskService.getTeamChartData(teamUser.getTeam());
		return new ResponseEntity<ChartData>(answeredTasks, HttpStatus.OK);
	}
}
