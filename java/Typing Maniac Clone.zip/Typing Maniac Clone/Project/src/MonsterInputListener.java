/**
 * This is an interface that should be implemented by listeners
 * @author Inna
 *
 */
public interface MonsterInputListener
{
	public void PauseRequest();
	
	public void RemoveRequest(String word);
		
	public void CharRequest(String typedChars);

	public void stopMusicRequest();
	
}
