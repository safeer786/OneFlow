import java.util.Iterator;
import java.util.Random;
import java.util.Stack;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Class to handle Words that need to be loaded from the library,
 * drawn on the screen and moved.
 * We use CopyOnWriteArrayList for the current words, so no ConcurrentModificationException occur
 */
public class WordFactory {

    private final int XOFFSET = 200;
    private int wordLength;
    private int wordsPerLevel;
    private int maxWidth, maxHeight;
    private Stack<Word> wordStorage;
    private CopyOnWriteArrayList<Word> currentWords;
    private Library library;
    private Random random = new Random();

    /**
     * Create a WordFactory according to current Game variables
     * @param wordLength    Length of the Words for this Level
     * @param wordsPerLevel Number of Words to load
     * @param maxWidth  Width of the screen, so Words are not drawn outside
     * @param maxHeight Height of the screen, so Words are not drawn outside
     */
    public WordFactory(int wordLength, int wordsPerLevel, int maxWidth, int maxHeight){
        this.wordLength = wordLength;
        this.wordsPerLevel = wordsPerLevel;
        this.maxWidth = maxWidth;
        this.maxHeight = maxHeight;
        this.wordStorage = new Stack<>();   //This is where the words are stored when we load them
        this.currentWords = new CopyOnWriteArrayList<>();  //This is where they get copied when they are in the game

        this.library = new Library();
        library.loadfile();
        readWords();    //Store the words in the Storage stack
    }

    /**
     * Set the Wordlength
     * @param length
     */
    public void setWordLength(int length){
        wordLength = length;
    }

    /**
     * Getter for Wordlength
     * @return
     */
    public int getWordLength(){
        return wordLength;
    }

    /**
     * Read in the Words from the library and Store
     * them on the WordStorage Stack
     */
    private void readWords(){
        this.wordStorage.clear();
        for(String wordString : library.get(wordLength, wordsPerLevel)){
            wordStorage.push(createWord(wordString));
        }
    }

    /**
     * Creates a new Word at a random Position
     * @param wordString   String of the Word
     * @return  New Word Object
     */
    public Word createWord(String wordString){
        int startPosition = random.nextInt(maxWidth-XOFFSET);
        Word word = new Word(wordString, startPosition, -10);
        return word;
    }

    /**
     * Add a new word from storage to the current words on the screen
     * @return
     */
    public boolean addWordToCurrent(){
        if (!wordStorage.isEmpty()){
            currentWords.add(wordStorage.pop());
            return true;
        }
        return false;
    }

    /**
     *
     * @return The List of all current words
     */
    public CopyOnWriteArrayList<Word> getCurrentWords(){
        return currentWords;
    }

    /**
     * Deletes a word from the current words
     * @param word The word to be deleted
     */
    public void destroyWord(Word word){
        currentWords.remove(word);
    }

    /**
     * Checks if an String fits one of the current words
     * Sets the Words solved value to true if it matches
     * @param input The String to match
     * @return True if there is a word on the screen that matches
     */
    public boolean matched(String input){
        for (Word word : currentWords){
            if(word.getWord().equals(input)){
                word.setSolved(true);
                return true;
            }
        }
        return false;
    }

    /**
     * Overloaded Method to destroy a word
     * @param word The word to be deleted
     * @return True if the word was deleted
     */
    public Boolean destroyWord(String word){
        for (Word item : currentWords)
        {
            if (item.getWord().equals(word))
                return currentWords.remove(item);
        }
        return false;
    }


    /**
     * Updates the Position values of all current words
     * according to velocity and speed
     * @param velocity The velocity
     * @param speed The speed
     */
    public void moveWords(float velocity, float speed){

        final Iterator<Word> iterator = this.currentWords.iterator();
        while(iterator.hasNext()){
            Word word = iterator.next();
            if((word.getY()+ speed)* velocity > maxHeight){
                currentWords.remove(word);
            }
            else {
                word.moveDown(velocity, speed);
            }
        }






    }


}
