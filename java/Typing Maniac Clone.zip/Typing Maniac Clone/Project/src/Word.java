/**
 * Basically a wrapper for a String
 * Adding Position values and a flag
 * to tell whether this word has been solved
 */
public class Word {

    private float x,y;
    private String word;
    private boolean isSolved;

    /**
     * Creates a new Word at the given position
     * @param word String of the Word
     * @param x x-Position
     * @param y y-Position
     */
    public Word(String word, float x, float y){
        this.word = word;
        this.x = x;
        this.y = y;
        this.isSolved = false;
    }

    /**
     * Returns the String of the word
     * @return String of the word
     */
    public String getWord() {
        return word;
    }

    /**
     * Return the X-Position
     * @return The X-Position
     */
    public float getX(){
        return this.x;
    }

    /**
     * Return the Y-Position
     * @return The Y-Position
     */
    public float getY(){
        return this.y;
    }

    /**
     * Set the solved Value of the word
     * @param solved True if solved, false otherwise
     */
    public void setSolved(boolean solved) {
        isSolved = solved;
    }

    /**
     * Check if a word is solved
     * @return True if solved, false otherwise
     */
    public boolean isSolved() {
        return isSolved;
    }

    /**
     * Update the x,y position of the word
     * according to velocity and speed
     * @param velocity The velocity
     * @param speed The speed
     */
    public void moveDown(float velocity, float speed){
        this.y = (this.y + speed)* velocity;
    }
}
