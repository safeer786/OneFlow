/**
 * This class deals with the user's input
 * It generates events whenever a key is pressed
 * and notifies the listeners
 * @author Inna Pirina
 */
import org.newdawn.slick.Input;
import org.newdawn.slick.KeyListener;

import java.util.ArrayList;


public class MonsterInput implements KeyListener{
	
	private String combinedTypedChars;                		//the word that was entered
	private ArrayList<MonsterInputListener> listeners;       //a collection of listeners of this class
		
	/**
	 * a default constructor
	 */
	public MonsterInput() 
	{
		combinedTypedChars = new String();
		listeners = new ArrayList<MonsterInputListener>();
	}

	/**
	 * this method adds listeners to the collection
	 * @param listener - a listener to add
	 */
	public void addListener(MonsterInputListener listener) 
	{
		listeners.add(listener);
	}

	/**
	 * this method sets the word to an empty string
	 */
	public void clearInput()
	{
		combinedTypedChars = "";
	}
	
	/**
	 * this method generates an event to notify the listener that a word was submitted
	 */
	public void submitCharacters()
	{	
		for (MonsterInputListener maniacInputListener : listeners) 
		{
			maniacInputListener.RemoveRequest(combinedTypedChars);
		}
		combinedTypedChars = "";
	}
	
	/**
	 * this method adds a typed character to a string
	 * and notifies a listener that a letter was typed
	 * @param chcaracter
	 */
	public void typedChars(Character chcaracter)
	{
		combinedTypedChars = combinedTypedChars + chcaracter;
		
		for (MonsterInputListener maniacInputListener : listeners) 
		{
			maniacInputListener.CharRequest(combinedTypedChars);
		}
	}
	
	/**
	 * this method removes the last typed character from the string
	 * it then sends a new string to a listener
	 */
	public void removeCharacter()
	{
		if(combinedTypedChars.length() != 0)
		{
			combinedTypedChars = combinedTypedChars.substring(0, combinedTypedChars.length()-1);
			
			for (MonsterInputListener maniacInputListener : listeners) 
			{
				maniacInputListener.CharRequest(combinedTypedChars);
			}	
		}
	}
	
	/**
	 * this method generates an event to notify the listener that a pause was requested
	 */
	public void requestPause()
	{
		for (MonsterInputListener maniacInputListener : listeners) 
		{
			maniacInputListener.PauseRequest();
		}
	}

	/**
	 * this method generates an event to notify the listener that a music stop was requested
	 */
	public void requestMusicStop()
	{
		for (MonsterInputListener maniacInputListener : listeners) 
		{
			maniacInputListener.stopMusicRequest();
		}
	}

	
	/**
	 * Implemented interface of KeyListener
	 */
	@Override
	public void inputEnded() {
		
	}

	@Override
	public void inputStarted() {
		
	}

	@Override
	public boolean isAcceptingInput() {
		return true;
	}

	@Override
	public void setInput(Input arg0) {
		
	}

	/**
	 * this method calls other methods whenever a correspondent key is pressed
	 */
	@Override
	public void keyPressed(int charCode, char character) {
		
		if(Character.isLetter(character))
			typedChars(character);
		
		if(charCode == Input.KEY_ENTER)
			submitCharacters();
		
		if(charCode == Input.KEY_BACK)
			removeCharacter();
		
		if(charCode == Input.KEY_ESCAPE)
			requestPause();
		
		if(charCode == Input.KEY_F7)
			requestMusicStop();
		
	}

	@Override
	public void keyReleased(int arg0, char arg1) {
		
	}
}
