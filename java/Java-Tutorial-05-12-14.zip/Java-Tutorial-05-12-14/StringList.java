/**
 * Data Structures 2009 / 2010
 * ch07 Array as instance variable example
 */
public class StringList 
{   
    // initial size - if none is given in constructor
    public static int INITIAL_SIZE = 3;
    
    String[] list;  // array instance variable
    int numElements;  // number of elements currently in list
    
    public StringList()
    {
        numElements = 0;
        list = new String[INITIAL_SIZE];
    }
    
    public StringList(int initialSize)
    {
        numElements = 0;
        list = new String[initialSize];
    }
    
    public void add(String item)
    {    
        // transfer list to a larger array when full
        if (numElements == list.length)
        {
            String[] tmp = new String[numElements + INITIAL_SIZE];
            for (int i=0; i < numElements; i++)
            {
                tmp[i] = list[i];
            }
            list = tmp;
        }
        
        // add item
        list[numElements] = item;
        numElements++;
        
    }
    
    public boolean contains(String item)
    {
        boolean found = false;
        for (int i=0; (i < numElements) && !found; i++)
        {
            if (list[i].equalsIgnoreCase(item))
            {
                found = true;
            }           
        }
        return found;
    }
    
    public String get(int index)
    {
        String result = null;
        if ((index >= 0) && (index < numElements))
        {
            result = list[index];
        }
        return result;
    }
    
    public String toString()
    {
        String rval = "[";
        for (int i=0; i < numElements; i++)
        {
            rval += list[i] + ", ";
        }
        rval = rval.substring(0, rval.length()-2); //remove trailing ", "
        rval += "]";
        return rval;
    }
     /**
    Insert String to Index.
    
    @param index -At what index
    @param item - The new value
    */
    public void insertAt(int index, String item)
    {
      String[] temp;
 
       temp = new String[list.length + 1];
       //Adding if First index
      if(index == 0)
      {
        temp[0]=item;
        for(int i=1;i<list.length +1 ;i++)
        {
          temp[i]=list[i-1];
        }
        list=new String [list.length + 1];
        list=temp;
        numElements++;
      }
      //Adding at last index by add method
      else if(index == list.length)
      {
        add(item);
      }
      //Adding in middle
      else
      {
        int k=0;
        for(int j=0;j<list.length +1 ;j++)
        {     
          if(j==index)
        {
          temp[j]=item;
        }
        else
        {
          temp[j]=list[k];
          k++;
        }
        }
        list=new String [list.length + 1];
        list=temp;
        numElements++;
      }
      
    }
 public String[] toArray()
 {
       String[] temp;
       temp = new String[list.length];
       temp=list;
       return temp;
 }
 public boolean remove(String item)
 {
   int ind=-1;
   boolean dec = true;
   String[] temp;
   temp = new String[list.length ];
   //search the element  
   for(int i=0;i<numElements;i++)
   {
     if(list[i].equals(item))
     {
       ind=i;
     }
   }
   //If not Found
   if(ind == -1)
   {
     System.out.println("item NOT Found");
     dec= false;
   }
   else
   {
     //Remove Form first index
     if(ind == 0)
     {
      for(int j=0;j<list.length -1 ;j++)
       {
         temp[j]=list[j+1];
       }
      list=new String [list.length - 1];
      list=temp;
       numElements--;
       
     }
     //Remove Form Last index
     
    else if(ind == numElements-1)
     {
       for(int k=0;k<numElements -1;k++)
       {
         temp[k]=list[k];
       }
       list=temp;
       numElements--;
     }
    //Remove Form middle
     
    else
    {
      int m=0;
           for(int l=0;l<numElements;l++)
       {
         if(l != ind)    
         {
           temp[m]=list[l];
           m++;
         }
       }
           list=temp;
           numElements--;
    }
   }
   return dec;
 }
}