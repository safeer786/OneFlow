public class JavaGivesHeadacheException extends Exception
{
    public JavaGivesHeadacheException()
    {
        super("Java Gives Headache Exception ");
    }
    
    public JavaGivesHeadacheException(String message)
    {
        super(message);
    }
}
