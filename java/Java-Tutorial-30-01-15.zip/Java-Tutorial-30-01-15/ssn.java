public class WrongSocialSecurityFormatException extends Exception
{
    public WrongSocialSecurityFormatException()
    {
        super("Wrong Social Security Format Exception ");
    }
    
    public WrongSocialSecurityFormatException(String message)
    {
        super(message);
    }
}
