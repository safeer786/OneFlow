/**
 * Read and print to the screen lines contained in
 * a UTF-8 text file specified in args[0].
 */
import java.io.*;

public class UTF8FileInputDemo
{
    public static final String ENCODING = "UTF-8";
    
    public static void main(String[] args)
    {
        
      //   make sure number of arguments is correct
        if (args.length != 1)
        {
            System.out.println("Usage: java UTF8FileInputDemo <filename>");
            System.exit(0);
        }
        System.out.println("NOTE MY code reads the input.txt and reads the content makes the new files.java from the content after removing spaces then prints massage in stdout and then i wrote the codes in created files manually");
        String fileName = args[0];//"input.txt";
        String fileName2;
        BufferedReader src;
        String line;
        File destFile =null; 
        PrintWriter dest = null;
        File destFile2 =null; 
        PrintWriter dest2 = null;
        System.out.println("The file " + fileName + " contains the following lines:");
        String end=" Exception";
        String ap;
        String result;
        String type=".java";
        try
        {
            // open file for reading, utf8
            src = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), ENCODING));
            dest2 = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("stdout.txt"), ENCODING)));
           //  dest = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), ENCODING)));
            // read input stream line-by-line and print each line to screen
            while ((line = src.readLine()) != null)
            {
              if(line.contains("Exception"))
              {destFile=new File(line);
                 dest2.println(line);
                line=line+type;
                result=line.replaceAll("\\s","");
               dest = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(result), ENCODING)));
              System.out.println("file created with name " + result);
              
              dest.close( );}
              else
              {
                ap=line+end;
                 dest2.println(ap);
                ap=ap+type;
                result=ap.replaceAll("\\s","");
                destFile=new File(ap);
                 dest = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(result), ENCODING)));
                 System.out.println("file created with name " + result);
               //   dest2.println(ap);
              dest.close( );}
                System.out.println(line);
            }
            
            // don't forget to close the file
            src.close();
            dest2.close();
            System.out.println("NOTE MY code reads the input.txt and reads the content makes the new files.java from the content after removing spaces then prints massage in stdout and then i wrote the codes in created files manually and also saved in files ssn and javaheadache");
        
        }
        catch (FileNotFoundException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);        
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }
    }
}