import junit.framework.TestCase;
import java.io.*;
import java.util.*;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class PalindromeTest extends TestCase {
  
    public void testisPalindrome_1()
    {
      //-- Test if a String is a palindrome (Empty String)
      Palindrome p1=new Palindrome();
      Palindrome2 p2=new Palindrome2();
      assertTrue(p1.isPalindrome(""));
      assertTrue(p2.isPalindrome(""));
    }
      
      
    public void testisPalindrome_2()
    {
      //-- Test if a String is a palindrome (String with length 1)
      Palindrome p1=new Palindrome();
      Palindrome2 p2=new Palindrome2();
      assertTrue(p1.isPalindrome("a"));
      assertTrue(p2.isPalindrome("a"));
    }
    public void testisPalindrome_3()
    {
      //-- Test if a String is a palindrome (String "Anna")
      Palindrome p1=new Palindrome();
      Palindrome2 p2=new Palindrome2();
      assertTrue(p1.isPalindrome("Anna"));
      assertTrue(p2.isPalindrome("Anna"));
    }
    public void testisPalindrome_4()
    {
      //-- Test if a String is a palindrome (String "Foo")
      Palindrome p1=new Palindrome();
      Palindrome2 p2=new Palindrome2();
      assertFalse(p1.isPalindrome("Foo"));
      assertFalse(p2.isPalindrome("Foo"));
    }
    public void testisPalindrome_5() 
    {
      //-- Test if a String is a palindrome (String "Able was i ere i saw Elba")
      Palindrome p1=new Palindrome();
      Palindrome2 p2=new Palindrome2();
      assertTrue(p1.isPalindrome("Able was i ere i saw Elba"));
      assertTrue(p2.isPalindrome("Able was i ere i saw Elba"));
    }
}