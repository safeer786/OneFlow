import java.util.*;
import java.io.*;
import java.lang.*;

public class Palindrome {
    
 public static boolean isPalindrome(String text)
 {
   {   // if length is 0 or 1 then String is palindrome
       //  text=text.toLowerCase();
        if(text.length() == 0 )
     {  return true;} 
         if(text.length() == 1 )
     {return true;}
         char a=text.charAt(0);//
         a=Character.toLowerCase(a);
         char b=text.charAt(text.length()-1);
         b=Character.toLowerCase(b);
        // int r= a.compareTo(b);
        if(a == b)
        return isPalindrome(text.substring(1, text.length()-1));
        return false;
    }
 }
}