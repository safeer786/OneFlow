import java.util.*;
import java.io.*;

public class Palindrome2 {
    
 public static boolean isPalindrome(String text)
 {
   {   // if length is 0 or 1 then String is palindrome
        text=text.toLowerCase();
        if(text.length() == 0 )
            return true; 
         if(text.length() == 1 )
            return true;
        for(int i=0;i<text.length()/2;i++)
     {
        if(text.charAt(i) == text.charAt(text.length()-i-1))
        {;}
        else
        {
          return false;
        }
        }
        
        return true;
    }
 }
}