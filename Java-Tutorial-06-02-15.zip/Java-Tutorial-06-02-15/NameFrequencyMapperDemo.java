import java.io.*;

public class NameFrequencyMapperDemo {
    public static void main(String[] args) {
      try{
        NameFrequencyMapper n=new NameFrequencyMapper("girlnames.txt","boynames.txt");
        NameFrequencyMapper n1=new NameFrequencyMapper();
        
        int [] f=n.lookupFrequency("Samantha");
      if(f[0]== -1)
      {
        System.out.println("not found in boys name ");
      }
      else
      {
        System.out.println(" found in boys name with frequency: " + f[0]);
        
      }
       if(f[1]== -1)
      {
        System.out.println("not found in girls name ");
      }
      else 
      {
      
        System.out.println(" found in girls name with frequency: " + f[1]);
      }
      int [] t=n.lookupFrequency("Samanth");
      if(t[0]== -1)
      {
        System.out.println("not found in boys name ");
      }
      else
      {
        System.out.println(" found in boys name with frequency: " + t[0]);
        
      }
       if(t[1]== -1)
      {
        System.out.println("not found in girls name ");
      }
      else 
      {
      
        System.out.println(" found in girls name with frequency: " + t[1]);
      }
        }
       catch (FileNotFoundException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);        
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }
    }
}