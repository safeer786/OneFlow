/* $Id$ */

/**
 * Contains a name and the frequency of that name 
 */
class NameFrequency  {
    private String name;
    private int frequency;
    
    /**
     * Creates a new NameFrequency with <it>aName</it> and 
     * the frequency <it>itsFrequency</it>
     */
    public NameFrequency(String aName, int itsFrequency)  {
        name = aName;
        frequency = itsFrequency;
    }
    
    /**
     * Return the name of this NameFrequency     
     * @return the name of this NameFrequency
     */
    public String getName()  {
        return name;
    }
    
    /**
     * Set the name of this NameFrequency
     * @parmam aName the name of this NameFrequency
     */
    public void setName(String aName)  {
        name = aName;
    }
    
    /**
     * Return the frequency of the name
     * @return the frequency of this NameFrequency
     */     
    public int getFrequency()  {        
        return frequency;
    }
    
    /**
     * Set the frequency of this NameFrequency
     * @parmam newFrequency the frequency of this NameFrequency
     */
    public void setFrequency(int newFrequency)  {        
        frequency = newFrequency;
    }
    
    /**
     * @return a String representation of this NameFrequency
     */
    public String toString()  {
        return name + ": " + frequency;
    }
    
    /**
     * Compares this NameFrequency case insensitive to another NameFrequency. 
     * @param other a NameFrequency 
     * @return true when other is equal to this Namefrequency otherwise false.
     */
    public boolean equalsIgnoreCase(NameFrequency other)  {
        if (other == null)  {
            return false;
        }
                             
        return name.equalsIgnoreCase(other.getName()) && frequency == other.getFrequency();
    }
    
    /**
     * Compares this NameFrequency to another NameFrequency. 
     * @param other a NameFrequency 
     * @return true when other is equal to this Namefrequency otherwise false.
     */
    public boolean equals(Object other)  {
        if (other == null)  {
            return false;
        }
        
        if (getClass() != other.getClass())  {
            return false;
        }
        
        NameFrequency aNameFrequency = (NameFrequency) other;        
        return equalsIgnoreCase(aNameFrequency);
    }
}