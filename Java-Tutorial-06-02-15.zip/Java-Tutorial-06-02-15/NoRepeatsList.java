/**
 * WS07 - SelfTest7 Solution
 * 
 * Modified OneWayNoRepeatsList.
 * 
 * An object of this class is a special kind of list. You can add to 
 * the end of the list, but you cannot change individual entries.
 * You can remove an entry by specifying the index or the String.
 * You can erase the entire list and start over. No entry may appear
 * more than once on the list. You can use int variables as position
 * markers into the list.
 */
public class NoRepeatsList {
    
    public static final int DEFAULT_SIZE = 50;
    //entry.length is the total number of items you have room
    //for on the list. countOfEntries is the number of items 
    //currently on the list.
    private int countOfEntries; //can be less than entry.length.
    private NameFrequency[] entry; 
    
    /**
     * Construct an empty list with the specified capacity.
     * @param initialSize the initial capacity
     */
    public NoRepeatsList(int initialSize) {
        entry = new NameFrequency[initialSize];
        countOfEntries = 0; 
    }
    
    /**
     * Creates an empty list with a capacity of DEFAULT_SIZE.
     */
    public NoRepeatsList() {
        entry = new NameFrequency[DEFAULT_SIZE];
        countOfEntries = 0; 
    }
    
    /**
     * Get the current number of entries in this list.
     * @return the current number of entries in this list
     */
    public int getNumberOfEntries() {
        return countOfEntries;
    } 

    /**
     * If the argument indicates a position on the list,
     * then the entry at that specified position is returned;
     * otherwise, null is returned.
     */
    public NameFrequency getEntryAt(int position) {
        if ((0 <= position) && (position < countOfEntries))
            return entry[position];
        else
            return null;
    }
    
    /**
     * Get a copy of the list
     * @return a copy of the list
     */
    public NameFrequency[] getList() {
        NameFrequency[] tmp = new NameFrequency[countOfEntries];
        for (int i=0; i < countOfEntries; i++) {
            tmp[i] = entry[i];
        }
        return tmp;
    }
    
    /**
     * Determine if this list is empty.
     * @return true if this list is empty, otherwise false
     */
    public boolean empty() {
        return (countOfEntries == 0);
    }
    
    /**
     * Remove all items from this list.
     */
    public void eraseList() {
        countOfEntries = 0;
    }
    
    /**
     * Postcondition: If item was not on the list, 
     * it has been added to the list.
     * @param item the item to add to this list
     */
    public void addItem(NameFrequency item) {
        if (! onList(item)) {
            if (countOfEntries == entry.length) {
                // resize
                NameFrequency[] tmp = new NameFrequency[entry.length + DEFAULT_SIZE];
                for (int i=0; i < entry.length; i++) {
                    tmp[i] = entry[i];
                }
                entry = tmp;
            }
            
            entry[countOfEntries] = item;
            countOfEntries++;
            
        }//else do nothing. Item is already on the list.
    }
    
    /**
     * Determine if item is on this list;
     * Does not differentiate between upper- and lowercase letters.
     * @param item the item to locate
     * @return true if item is on this list, false otherwise
     */
    public boolean onList(NameFrequency item) {
        boolean found = false;
        int i = 0;
        while ((! found) && (i < countOfEntries)) {
            if (item.equalsIgnoreCase(entry[i]))
                found = true;
            else
                i++;
        }
        return found;
    }
        
    /**
     * Find item on this list (ignoring case).
     * @param item the item to find
     * @return the index of item if found, otherwise -1
     */
    public int find(NameFrequency item) {
        boolean found = false;
        int indexOfItem = -1;
        int i = 0;
        while ((! found) && (i < countOfEntries)) {
            if (item.equalsIgnoreCase(entry[i]))
                found = true;
            else
                i++;
        }
        if (found) {
            indexOfItem = i;
        }
        return indexOfItem;
    }
    
    /**
     * Return the frequency for a given name
     * @param aName the name to lookup
     * @return the frequency of aName or -1 when aName is not found
     */
    public int getFrequencyForName(String aName)  {
        int i = 0;
        int result = -1;
        while (i<countOfEntries)  {
            if (entry[i].getName().equalsIgnoreCase(aName))  {
                result = entry[i].getFrequency();
                break;
            }
            i++;
        }
 
        return result;
    }
    /**
     * Remove item at index from this list.
     * Precondition: index is valid
     * @param index the index of the item to remove
     */
    public void remove(int index) {
        if (index >= 0 && index < countOfEntries) {
            for (int i=index; i < countOfEntries; i++) {
                entry[i] = entry[i+1];
            }
            countOfEntries--;
        } 
    }
    
    /**
     * Remove item from this list.
     * @param item the item to remove
     */
    public void remove(NameFrequency item) {
        int indexOfItem = find(item);
        if (indexOfItem >= 0) {
            remove(indexOfItem);
        }
    }
    
    /**
     * Get a String representation of this list, with positions
     * startin at 1.
     * @return a String representation of this list
     */
    public String toString() {
        String rval = "";
        for (int i=0; i < countOfEntries; i++) {
            rval += (i+1) + " " + entry[i] + "\n";
        }
        return rval;
    }
    
    /**
     * Determine if this list and otherList are equal.
     * @return true if they are equal, false otherwise
     */
    public boolean equals(NoRepeatsList otherList) {
        boolean areEqual = false;
        int i = 0;
        if ((otherList != null) &&
            (countOfEntries == otherList.countOfEntries)) {
            
            areEqual = true;
            while (areEqual && (i < countOfEntries)) {
                if (entry[i].equalsIgnoreCase(otherList.entry[i])) {
                    i++;
                } else {
                    areEqual = false;
                }
            }
        }
        return areEqual;
    }
}