import java.io.*;
import java.util.*;
class NameFrequencyMapper  {
 private   NameFrequency obj;
 private   NoRepeatsList blist;
 private   NoRepeatsList glist;

public NameFrequencyMapper(String girlsFileName,String boysFileName)throws FileNotFoundException,IOException
{
  String line;
  String[] words=new String[2];
  BufferedReader src1;
  String encoding="UTF-8";
  int fre;
  BufferedReader src2;
  //NameFrequency obj;
  blist=new NoRepeatsList();
  glist=new NoRepeatsList();
  try 
  {
    src1 = new BufferedReader(new InputStreamReader(new FileInputStream(girlsFileName),encoding));
    src2 = new BufferedReader(new InputStreamReader(new FileInputStream(boysFileName), encoding));
    while ((line = src1.readLine()) != null)
    {
          words = line.split("\\s+");
          fre = Integer.parseInt(words[1]);
          obj=new NameFrequency(words[0],fre);
          glist.addItem(obj);
    }
    while ((line = src2.readLine()) != null)
    {
          words = line.split("\\s+");
          fre = Integer.parseInt(words[1]);
          obj=new NameFrequency(words[0],fre);
          blist.addItem(obj);
    }

  src1.close();
  src2.close();
  }
    catch (FileNotFoundException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);        
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }

}
public NameFrequencyMapper()throws FileNotFoundException,IOException
{
  String line;
  String[] words=new String[2];
  BufferedReader src1;
  String encoding="UTF-8";
  int fre;
  BufferedReader src2;
  //NameFrequency obj;
  blist=new NoRepeatsList();
  glist=new NoRepeatsList();
  try 
  {
    src1 = new BufferedReader(new InputStreamReader(new FileInputStream("girlnames.txt"),encoding));
    src2 = new BufferedReader(new InputStreamReader(new FileInputStream("boynames.txt"), encoding));
    while ((line = src1.readLine()) != null)
    {
          words = line.split("\\s+");
          fre = Integer.parseInt(words[1]);
          obj=new NameFrequency(words[0],fre);
          glist.addItem(obj);
    }
    while ((line = src2.readLine()) != null)
    {
          words = line.split("\\s+");
          fre = Integer.parseInt(words[1]);
          obj=new NameFrequency(words[0],fre);
          blist.addItem(obj);
    }

  src1.close();
  src2.close();
  }
    catch (FileNotFoundException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);        
        }
        catch (UnsupportedEncodingException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
            System.exit(0);
        }

}
public int[] lookupFrequency(String forName)
{
  int[] f=new int[2];
  
  f[0]=blist.getFrequencyForName(forName);
  f[1]=glist.getFrequencyForName(forName);
  return f;
}
    
}