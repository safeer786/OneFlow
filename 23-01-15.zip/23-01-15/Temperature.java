/**
 * Temperature interface provides a set of methods to compare and convert
 * Fahrenheit and Celsius values.
 * @author Jochen
 */
public interface Temperature {

  /**
   * Sets temperature.
   * @param degrees value of this temperature
   */
  public void setDegree(double degrees);
  
  /**
   * Returns temperature in Celsius.
   * @return value of this Temperature in degrees Celsius
   */
  public double getCelsius();
    
  /**
   * Returns temperature in Fahrenheit.
   * @return the value of this Temperature in degrees Fahrenheit.
   */
  public double getFahrenheit(); 
  
  /**
   * Returns true or false depending on whether this temperature is equal to another Temperature.
   * @return true or false depending on whether this temperature is equal to another Temperature.
   */
  public boolean equals(Temperature another);
  
  /**
   * Returns true or false depending on whether this temperature is greater than another Temperature.
   * @return true or false depending on whether this temperature is greater than another Temperature.
   */
  public boolean isGreaterThan(Temperature another);
  
  /**
   * Returns true or false depending on whether this temperature is less than another Temperature.
   * @return true or false depending on whether this temperature is greater than another Temperature.
   */
  public boolean isLessThan(Temperature another);
}
