public class Fahrenheit implements Temperature {
  public double temperature;
  public static final double EPSILON = 0.01;
  public Fahrenheit()
  {
    temperature = 0.0;
  }
  public Fahrenheit(double newDegrees)
  {
    temperature=newDegrees;
  }
  public void setDegree(double newValue)
  {
    temperature=newValue;
  }
public double getFahrenheit()
{
    return temperature;
}
public double getCelsius()
{
  double temp;
   temp =temperature;
  temp=5 * (temp - 32)/9;
  return(Math.round(temp*10)/10.0);
}
public boolean isGreaterThan(Temperature another)
{
    if(temperature > another.getFahrenheit())
  {return true;}
  else
  {return false;}
}
public boolean isLessThan(Temperature another)
{
    if(temperature < another.getFahrenheit())
  {return true;}
  else
  {return false;}
}
public boolean equals(Temperature another)
{
  if(Math.abs(temperature - another.getFahrenheit()) < EPSILON)
  {
    return true;
  }
  else
  {
    return false;
  }
}
}