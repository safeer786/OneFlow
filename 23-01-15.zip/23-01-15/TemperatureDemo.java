public class TemperatureDemo
{
    public static void main(String[] args)
    {
        Temperature t1 = new Celsius(20.00);
        Temperature t2 = new Fahrenheit(68.00);        
        Temperature t3 = new Celsius(22.00);
        System.out.println("t1 is 20 Celsius t2 is 68 Fahrenheit t3 is 22 Celsius"); 
        if(t1.isGreaterThan(t2))
        {
          System.out.println("t1 is greater than t2");
        }
        if(t1.isLessThan(t2))
        {
          System.out.println("t1 is less than t2");
        }
        if(t1.equals(t2))
        {
          System.out.println("t1 is equal to t2");
        }
        System.out.println("t1 is 20 and in Fahrenheit = " + t1.getFahrenheit());
        if(t1.isGreaterThan(t3))
        {
          System.out.println("t1 is greater than t3");
        }
        if(t1.isLessThan(t3))
        {
          System.out.println("t1 is less than t3");
        }
        if(t1.equals(t3))
        {
          System.out.println("t1 is equal to t3");
        }
        System.out.println("t3 is 22 and in Fahrenheit = " + t3.getFahrenheit());
    }

}