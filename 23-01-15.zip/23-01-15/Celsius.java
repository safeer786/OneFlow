public class Celsius implements Temperature {
  public static final double EPSILON = 0.01;
  private double temperature;
  public Celsius()
  {
    temperature = 0.0;
  }
  public Celsius(double newDegrees)
  {
    temperature=newDegrees;
  }
  public void setDegree(double newValue)
  {
    temperature=newValue;
  }
public double getCelsius()
{
  return temperature;
}
public double getFahrenheit()
{
  double temp;
   temp =temperature;
   temp=(temp * 1.8) + 32;
  return (Math.round(temp*10)/10.0);
}
public boolean isGreaterThan(Temperature another)
{
  if(temperature > another.getCelsius())
  {return true;}
  else
  {return false;}
}
public boolean isLessThan(Temperature another)
{
    if(temperature < another.getCelsius()) 
  {return true;}
  else
  {return false;}
}
public boolean equals(Temperature another)
{
  if(Math.abs(temperature - another.getCelsius()) < EPSILON)
  {
    return true;
  }
  else
  {
    return false;
  }
}
}