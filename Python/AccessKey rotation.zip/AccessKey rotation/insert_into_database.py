#!/usr/bin/python
# -*- coding: utf-8 -*-
from pyawslogin import get_cerdentials
import getpass
import argparse
from os.path import expanduser, exists
from os import makedirs
import sys
import csv
import pymysql
import sys
def connect_to_db():
	rds_host  = "db-iam-accesskeyrotation.ciqcqozw5uwy.eu-central-1.rds.amazonaws.com"
	name = 'Admin'
	password = 'AZDIAMPW'
	db_name = 'DB_IAM_ACCESSKEYROTATION'
	try:
		conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=1000)
	except:
		print "ERROR: Unexpected error: Could not connect to MySql instance."
		sys.exit()
	print "SUCCESS: Connection to RDS mysql instance succeeded"
	return conn
def insert_into_database(conn,table,username,account,email):
	item_count = 0    
	with conn.cursor() as cur:
		cur.execute('INSERT INTO '+table+' (User,Account,Email) VALUES("'+username+'","'+account+'","'+email+'")')
		conn.commit()
		cur.execute("SELECT * FROM "+table)
		for row in cur:
			item_count += 1
			print(row)
	return "Added %d items from RDS MySQL table" %(item_count)
domain = 'win\\'
username = "ue7yww5"
password = "tEST4!\"ยง"
conn = connect_to_db()
table= "User"      #user or exception
usernames=["username1","username1"]     #username
accounts=["account for user 1","account for user 2"]     #account
emails=["email for user1", "email for user2"]            #emails
iam_client=get_iam_client(domain+username,password,'303747409146','ADFS-InfrastructureOperator')
for i in range(len(username)):
	insert_into_database(conn,table,usernames[i],accounts[i],emails[i])
	
# add the username and password in the script and the usernames accounts emails u want to save in the database with the name of the table Users or exception table