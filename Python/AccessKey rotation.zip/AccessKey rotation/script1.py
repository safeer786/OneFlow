#!/usr/bin/python
# -*- coding: utf-8 -*-
import boto3
import datetime
from pyawslogin import get_cerdentials
import getpass
import argparse
import json
from os.path import expanduser, exists
from os import makedirs
import sys
import csv
import pymysql
import sys
import logging
import traceback
def get_username_password():
	domain = 'win\\'
	# Get the federated credentials from the user
	print "Username:",
	#username = raw_input()
	username = 'ue7yww5'
	password = "tEST4!\"ยง"
	print username
	print password
	return domain+username, password
def get_boto_session(username, password, account_id, role):
	access_key, secret_key, session_token = get_cerdentials(username, password, account_id, role )
	if not access_key:
		sys.exit('you are not authorized to login to this account:'+ account_id)
	session = boto3.Session(
			aws_access_key_id= access_key,
			aws_secret_access_key= secret_key,
			aws_session_token= session_token,
		)
	return session
def get_iam_client(username, password, account_id, role):
	session = get_boto_session(username, password, account_id, role)
	iam_client = session.client('iam')
	return iam_client
def get_ec2_client(username, password, account_id, role):
	session = get_boto_session(username, password, account_id, role)
	ec2_client = session.client('ec2')
	return ec2_client
def create_user(iam_client,username):
	user = iam_client.create_user(UserName=username)
	return user
def generate_accessKey(iam_client,username):
	response = iam_client.create_access_key(UserName=username)
	print(response['AccessKey'])
	secret_key=response['AccessKey']
	print secret_key['SecretAccessKey']
	return response['AccessKey']
def get_sesArn(account_id,from_email):
	sesArn = 'arn:aws:ses:us-east-1:'+account_id+':identity/' + from_email
	return sesArn

def buildEmailHeader(account_id,user):
	header = '<p><font size="4">Dear CloudOps-Team,</p>'
	header += '<p>this is an automated -alert for account ' + str(account_id) + 'the User '+str(user)+' which was triggered because of the access key expiration PLEASE change your AccessKey:.<br> </p>'
	header += '<style> table {font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th { border: 1px solid #dddddd; text-align: center; padding: 8px;} </style><table>'
	header += '<th>Account</th><th>UserName</th><th>New AccessKey</th>'
	return header
def build_new_accesskey_email(AccessKey,account_id,user,secreat_key):
	email = buildEmailHeader(account_id,user)
	email +='<tr><td>'+ str(account_id) +'</td><td>'+str(user) +'</td><td>'+  str(AccessKey)+'</td></tr>'
	email += "</table>"
	email += '<br><p> Your SecreatKey is : '+str(secreat_key)+'</p>' 
	return email
def build_accesskey_expiry_email(AccessKey,account_id,user):
	email = buildEmailHeader(account_id,user)
	email +='<tr><td>'+ str(account_id) +'</td><td>'+str(user) +'</td><td>'+  str(AccessKey)+'</td></tr>'
	email += "</table>"
	email += "<p> you will receive the new access key shortly and you would have to change your access key in the next 20 days </p>"
	return email
def get_subject(account_id,user):
	subject = 'AWS -alert for account: ' + str(account_id) + 'for user ' + str(user) + 'Access Key Expiration'
	return subject
def get_subject_newKey(account_id,user):
	subject = 'AWS -alert for account: ' + str(account_id) + 'for user ' + str(user) + 'New AccessKey '
	return subject
def get_subject_deleteKey(account_id,user):
	subject = 'AWS -alert for account: ' + str(account_id) + 'for user ' + str(user) + 'key deletion '
	return subject
def build_delete_email(AccessKey,account_id,user):
	email='<p>Dear user ' +str(user)+' your old AccessKey '+str(AccessKey)+' for Account '+str(account_id)+'('+str(getAccountName(account_id))+') has been deleted we hope you had changed your key :)  </p>'
	return email
def send_email_notification(To,From,SUBJECT,BODY,SESARN):
    client = boto3.client('ses',region_name='us-east-1')
    try:
        send_response = client.send_email(Source=From,
                                          Destination={'ToAddresses': [To]},
                                          Message={
                                            'Subject': {
                                             'Charset': 'UTF-8',
                                             'Data': SUBJECT,
                                             },
                                            'Body': {
                                             'Html': {
                                              'Charset': 'UTF-8',
                                              'Data': BODY
                                              }
                                             }
                                           
                                            },										  
                                          SourceArn=SESARN
                                            )
        print('Successfuly send the email with message ID: ' + send_response['MessageId'])
    except:
        print('Failed to send email, check the stack trace below.')
        traceback.print_exc()
def delete_access_key(iam_client,user,access_key):
	response = client.delete_access_key(AccessKeyId=access_key,UserName=user)
	return response
def getAccountName(accountNo):
	if(accountNo=='874233888769'):
		return 'SBX'
	if(accountNo=='284894803213'):
		return 'PROD'
	if(accountNo=='784550693460'):
		return 'DEV'
	if(accountNo=='966497653753'):
		return 'POC'
	if(accountNo=='303747409146'):
		return 'CC'
def get_users(iam_client):
    response = iam_client.list_users()
    users = response['Users']
    is_truncated = response['IsTruncated']
    if is_truncated:
        marker = response['Marker']
    while is_truncated:
        response = iam_client.list_users(Marker= marker)
        users.extend(response['Users'])
        is_truncated = response['IsTruncated']
        if is_truncated:
            marker = response['Marker']
    return users
def get_AccessKeys(iam_client,user):
    response = iam_client.list_access_keys(UserName = user)
    user_access_keys = response['AccessKeyMetadata']
    is_truncated = response['IsTruncated']
    if is_truncated:
        marker = response['Marker']
    while is_truncated:
        response = iam_client.list_access_keys(UserName = user, Marker= marker)
        user_access_keys.extend(response['AccessKeyMetadata'])
        is_truncated = response['IsTruncated']
        if is_truncated:
            marker = response['Marker']
    return user_access_keys
#calculation of days
#date difference
from datetime import datetime
def days_between2(d1):
    d1 = datetime.strptime(d1, "%Y-%m-%d")
    d2 = datetime.now.strptime(d2, "%Y-%m-%d")	
    return abs((d2 - d1).days)
def days_between2(d1, d2):
    d1 = datetime.strptime(d1, "%Y-%m-%d")
    d2 = datetime.strptime(d2, "%Y-%m-%d")	
    return abs((d2 - d1).days)
#database part
def connect_to_db():
	rds_host  = "db-iam-accesskeyrotation.ciqcqozw5uwy.eu-central-1.rds.amazonaws.com"
	name = 'Admin'
	password = 'AZDIAMPW'
	db_name = 'DB_IAM_ACCESSKEYROTATION'
	try:
		conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=1000)
	except:
		print "ERROR: Unexpected error: Could not connect to MySql instance."
		sys.exit()
	print "SUCCESS: Connection to RDS mysql instance succeeded"
	return conn
def insert_into_database(conn,username,account,email):
	item_count = 0    
	with conn.cursor() as cur:
		#cur.execute("CREATE TABLE hahaha ( User  varchar(255) NOT NULL,Account varchar(255) NOT NULL , Email varchar(255) NOT NULL)")
		cur.execute('INSERT INTO Users (User,Account,Email) VALUES("'+username+'","'+account+'","'+email+'")')
		conn.commit()
		cur.execute("SELECT * FROM Users")
		for row in cur:
			item_count += 1
			print(row)
	return "Added %d items from RDS MySQL table" %(item_count)
def get_emailaddress(conn,username,account):
	item_count=0
	with conn.cursor() as cur:
		cur.execute('Select Email From Users Where( User = "'+username+'" And Account = "'+account+'")')
		return cur
def check_notIn_exception_table(conn,username,account):
	item_count = 0    
	with conn.cursor() as cur:
		cur.execute('SELECT * FROM ExceptionUsers Where (User = "'+username+'" And Account = "'+account+'")')
		if len(cur) != 0:
			return False
	return True

def start():
	#############dont need in the lamda function#########
	username,password=get_username_password()
	iam_client=get_iam_client(username,password,'966497653753','ADFS-AdminAccess')
	account_id='966497653753'
	#####################################################
	#iam_client=boto3.client('iam') #uncomment this in lamda function + add account_id as enviorment variable
	#####################################################
	start_date=datetime(datetime.datetime(2018, 08, 20) # change this date to the first time you will use this code
	d2 = datetime.now.strptime(d2, "%Y-%m-%d")
	conn=connect_to_db()
	from_email="extern.mian_safeerahmed@allianz.de"
	ses=get_sesArn(account_id,from_email)
	users=get_users(iam_client)
	i=0 #bullshit
	for user in users:
		AccessKeys=get_AccessKeys(iam_client,user['UserName'])
		keys=len(AccessKeys)
		creationdate=[]
		if(check_noIn_exception_table(conn,user['UserName'],getAccountName(account_id))):
			for AccessKey in AccessKeys:
				creationdate=str(AccessKey['CreateDate'].strftime("%Y-%m-%d"))
				if (days_between(start_date) == 0 ):
					if (keys > 0):
						email_body=build_accesskey_expiry_email(AccessKey['AccessKeyId'],account_id,user['UserName'])
						subject=get_subject(account_id,user['UserName'])
						new_subject=get_subject_newKey(account_id,user['UserName'])
						response=generate_accessKey(user['UserName'])
						email_body_new=build_new_accesskey_email(response['AccessKeyId'],account_id,user['UserName'],response['SecretAccessKey'])
						emails=get_emailaddress(conn,user['UserName'],getAccountName(account_id))
						for email in emails:
							send_email_notification(email[0],from_email,subject,email_body,ses)
							send_email_notification(email[0],from_email,new_subject,email_body_new,ses)					
				elif (days_between(start_date) == 30):
					if(days_between(creationdate) > 30 :	
						email_body=build_delete_email(AccessKey['AccessKeyId'],account_id,user['UserName'])
						delete_subject=get_subject_deleteKey(account_id,user['UserName'])
						result=delete_access_key(iam_client,user['UserName'],AccessKey['AccessKeyId'])
						emails=get_emailaddress(conn,user['UserName'],getAccountName(account_id))
						for email in emails:
							send_email_notification(email[0],from_email,delete_subject,email_body,ses)					
start()

