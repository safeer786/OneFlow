import junit.framework.TestCase;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 */
public class TwoDimensionalArrayUtilsTest extends TestCase {
   
   /**
    * Test are equal. Expect false;
    */
   public void testareEqual() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      String [][] testArray1 = {
         {"Hallo","Wet"},
         {"Guten","Tag"}};
      
      assertFalse(TwoDimensionalArrayUtils.areEqual(testArray,testArray1));
   }
   /**
    * Test are equal. Expect True;
    */
      public void testareEqual2() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      String [][] testArray1 = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      
      assertTrue(TwoDimensionalArrayUtils.areEqual(testArray,testArray1));
   }

      /**
    * Test are equal. Expect False;
    */
      public void testareEqual1() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      String [][] testArray1 = {
         {"Hallo","Welt"},
         };
      
      assertFalse(TwoDimensionalArrayUtils.areEqual(testArray,testArray1));
   }
      /**
    * Test are equal. Expect False;
    */
      public void testareEqual3() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      String [][] testArray1 = {
         {"Hallo","Welt"},
         {"Guten"}};
      
      assertFalse(TwoDimensionalArrayUtils.areEqual(testArray,testArray1));
   }
       /**
    * Test are equal. Expect False Null case;
    */
      public void testareEqual4() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      String [][] testArray1 ={};
      
      assertFalse(TwoDimensionalArrayUtils.areEqual(testArray,testArray1));
   }
      /**
    * Test flatten. Expect True;
    */
      public void testflatten() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      String [] testArray1 = {"Hallo","Welt","Guten","Tag"};
        Object [] array ;
        int count=0;
     for(int j=0;j<testArray.length;j++)
     {
       count=count+testArray[j].length;
     }
        array = new Object [count];
       array=TwoDimensionalArrayUtils.flatten(testArray);
       for(int i=0;i< testArray1.length;i++)
       { assertEquals(array[i],testArray1[i]);}
   }
    
     
   /* Add more test methods.... */
      /**
    * Test isRagged. Expect false;
    */
   public void testIsRagged1() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten","Tag"}};
      
      assertFalse(TwoDimensionalArrayUtils.isRagged(testArray));
   }
   /* Add more test methods.... */
      /**
    * Test isRagged. Expect True;
    */
   public void testIsRagged2() {
      String [][] testArray = {
         {"Hallo","Welt"},
         {"Guten"}};
      
      assertTrue(TwoDimensionalArrayUtils.isRagged(testArray));
   }
   
      /**
    * Test isRagged. Expect Flase one row;
    */
      public void testIsRagged3() {
      String [][] testArray = {
         {"Hallo","Welt"}
      };
      
      assertFalse(TwoDimensionalArrayUtils.isRagged(testArray));
   }
        
   /* Add more test methods.... */


}
