import java.lang.Object;
import java.util.*;
public class TwoDimensionalArrayUtils{
  
   public static boolean areEqual(java.lang.Object[][] arrayOne,java.lang.Object[][] arrayTwo)
   {
     boolean dec=false;
     //compare size
     if(arrayOne.length == arrayTwo.length) 
     {
       
   
           dec=true;
      
     }
     else
     {
       return false;
     }
     for (int row=0; row < arrayOne.length; row++)
   {
   for (int col=0; col < arrayOne[row].length; col++)
{
     //compare col of each row
     if(arrayOne[row].length != arrayTwo[row].length)
     {
       return false;
     }
     //checks if elements are same if not return false at that point
     if(arrayOne[row][col]== arrayTwo[row][col])
     {
       dec= true;
     }
     else
     {
       dec = false;
      return dec;
     }
   }
}
  return dec;
   }
   public static java.lang.Object[] flatten(java.lang.Object[][] anArray)
   {  
     int count=0;
     //calculate total size for oneD array
     for(int j=0;j<anArray.length;j++)
     {
       count=count+anArray[j].length;
     }
     Object [] arrayOneD = new Object [count];
     int i=0;
     for(int row= 0;row < anArray.length ; row++)
     {
       for(int col =0; col<anArray[row].length; col++)
       {
         //copy elements
         arrayOneD[i]= anArray[row][col];
         i++;
       }
     }
     return arrayOneD;
   }
   public static boolean isRagged(java.lang.Object[][] anArray)
   {
      boolean dec=true;
      //We assume that an empty array and an array with one row are not ragged
      if(anArray.length == 1 || anArray==null)
      {
        return false;
      }
     for (int row=1; row < anArray.length; row++)
   {
     if(anArray[row].length == anArray[row-1].length)
     {
       dec= false;
     }
     else
     {
       dec = true;
      return dec;
     }
   }
return dec;
}
}